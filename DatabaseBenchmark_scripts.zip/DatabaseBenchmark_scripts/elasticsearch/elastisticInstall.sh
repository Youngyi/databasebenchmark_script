sudo locale-gen zh_CN.UTF-8
sudo apt-get update
sudo apt-get install default-jre -y
sudo apt-get install default-jdk
sudo apt-get install oracle-java8-installer -y
sudo apt-get install software-properties-common
sudo add-apt-repository "deb http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main"
sudo apt-get update
sudo apt-get install oracle-java8-installer
wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-5.5.1.zip
sudo apt install unzip
unzip elasticsearch-5.5.1.zip
sudo sysctl -w vm.max_map_count=262144

cd elasticsearch-5.5.1
./bin/elasticsearch -d
