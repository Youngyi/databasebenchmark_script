#性能测试 6.1-6.2
echo 'default.6.1-6.2-load delete and truncate  ----- start -----'>> cluster_load_detele_truncate.log 
date >> cluster_load_detele_truncate.log
# clusters_vm1_vm2_vm3_create_table
#---------------  server 控制中心 or client 
# echo ''| POST 'http://127.0.0.1:8123/'

# echo 'CREATE TABLE stations_local (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE stations_all AS  stations_local ENGINE = Distributed(perftest_3shards_1replicas, default,  stations_local, rand())'| POST 'http://127.0.0.1:8123/'

# echo 'CREATE TABLE lines_local (LINEID String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE lines_all AS  lines_local ENGINE = Distributed(perftest_3shards_1replicas, default,  lines_local, rand())'| POST 'http://127.0.0.1:8123/'

# echo 'CREATE TABLE subtype_local (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE subtype_all AS subtype_local ENGINE = Distributed(perftest_3shards_1replicas, default,  subtype_local, rand())'| POST 'http://127.0.0.1:8123/'

# echo 'CREATE TABLE kpi_local (STATIONID String, LINEID String, DIRECTION String, DTKPI Datetime, DTBUSINESS Date, KPI Int64) ENGINE = MergeTree(DTBUSINESS,(STATIONID, LINEID, DIRECTION, DTKPI, KPI),8192)'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE kpi_all AS  kpi_local ENGINE = Distributed(perftest_3shards_1replicas, default, kpi_local, rand())'| POST 'http://127.0.0.1:8123/'

# echo 'CREATE TABLE transac_local ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTBUSINESS Date,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 )ENGINE = MergeTree(DTBUSINESS,(ID,STATIONIDIN,STATIONIDOUT,DTIN,DTOUT,OCTOPUS,SUBTYPE,TIME),8192)'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE transac_all AS  transac_local ENGINE = Distributed(perftest_3shards_1replicas, default, transac_local, rand())'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE transac_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://127.0.0.1:8123/'

#---------------    vm1
# clusters_vm1_vm2_vm3_create_table
# echo ''| POST 'http://52.231.186.4:8123/'
# echo 'DROP  DATABASE  default'| POST 'http://52.231.191.79:8123/'
echo 'CREATE  DATABASE  IF  NOT  EXISTS  default'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE stations_local (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE stations_all AS  stations_local ENGINE = Distributed(perftest_3shards_1replicas, default,  stations_local, rand())'| POST 'http://52.231.186.4:8123/'

echo 'CREATE TABLE lines_local (LINEID String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE lines_all AS  lines_local ENGINE = Distributed(perftest_3shards_1replicas, default,  lines_local, rand())'| POST 'http://52.231.186.4:8123/'

echo 'CREATE TABLE subtype_local (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE subtype_all AS subtype_local ENGINE = Distributed(perftest_3shards_1replicas, default,  subtype_local, rand())'| POST 'http://52.231.186.4:8123/'

echo 'CREATE TABLE kpi_local (STATIONID String, LINEID String, DIRECTION String, DTKPI Datetime, DTBUSINESS Date, KPI Int64) ENGINE = MergeTree(DTBUSINESS,(STATIONID, LINEID, DIRECTION, DTKPI, KPI),8192)'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE kpi_all AS  kpi_local ENGINE = Distributed(perftest_3shards_1replicas, default, kpi_local, rand())'| POST 'http://52.231.186.4:8123/'


echo 'CREATE TABLE transac_local ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTBUSINESS Date,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 )ENGINE = MergeTree(DTBUSINESS,(ID,STATIONIDIN,STATIONIDOUT,DTIN,DTOUT,OCTOPUS,SUBTYPE,TIME),8192)'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE transac_all AS  transac_local ENGINE = Distributed(perftest_3shards_1replicas, default, transac_local, rand())'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE transac_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.4:8123/'

#---------------    vm2
# clusters_vm1_vm2_vm3_create_table
# echo ''| POST 'http://52.231.191.79:8123/'
# echo 'DROP  DATABASE  default'| POST 'http://52.231.191.79:8123/'
echo 'CREATE  DATABASE  IF  NOT  EXISTS  default'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE stations_local (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE stations_all AS  stations_local ENGINE = Distributed(perftest_3shards_1replicas, default,  stations_local, rand())'| POST 'http://52.231.191.79:8123/'

echo 'CREATE TABLE lines_local (LINEID String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE lines_all AS  lines_local ENGINE = Distributed(perftest_3shards_1replicas, default,  lines_local, rand())'| POST 'http://52.231.191.79:8123/'

echo 'CREATE TABLE subtype_local (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE subtype_all AS subtype_local ENGINE = Distributed(perftest_3shards_1replicas, default,  subtype_local, rand())'| POST 'http://52.231.191.79:8123/'

echo 'CREATE TABLE kpi_local (STATIONID String, LINEID String, DIRECTION String, DTKPI Datetime, DTBUSINESS Date, KPI Int64) ENGINE = MergeTree(DTBUSINESS,(STATIONID, LINEID, DIRECTION, DTKPI, KPI),8192)'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE kpi_all AS  kpi_local ENGINE = Distributed(perftest_3shards_1replicas, default, kpi_local, rand())'| POST 'http://52.231.191.79:8123/'

echo 'CREATE TABLE transac_local ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTBUSINESS Date,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 )ENGINE = MergeTree(DTBUSINESS,(ID,STATIONIDIN,STATIONIDOUT,DTIN,DTOUT,OCTOPUS,SUBTYPE,TIME),8192)'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE transac_all AS  transac_local ENGINE = Distributed(perftest_3shards_1replicas, default, transac_local, rand())'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE transac_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.191.79:8123/'


#---------------    vm
# clusters_vm1_vm2_vm3_create_table
# echo ''| POST 'http://52.231.186.4:8123/'
# echo 'DROP  DATABASE   default'| POST 'http://52.231.190.32:8123/'
echo 'CREATE  DATABASE  IF  NOT  EXISTS  default'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE stations_local (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE stations_all AS  stations_local ENGINE = Distributed(perftest_3shards_1replicas, default,  stations_local, rand())'| POST 'http://52.231.190.32:8123/'

echo 'CREATE TABLE lines_local (LINEID String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE lines_all AS  lines_local ENGINE = Distributed(perftest_3shards_1replicas, default,  lines_local, rand())'| POST 'http://52.231.190.32:8123/'

echo 'CREATE TABLE subtype_local (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE subtype_all AS subtype_local ENGINE = Distributed(perftest_3shards_1replicas, default,  subtype_local, rand())'| POST 'http://52.231.190.32:8123/'

echo 'CREATE TABLE kpi_local (STATIONID String, LINEID String, DIRECTION String, DTKPI Datetime, DTBUSINESS Date, KPI Int64) ENGINE = MergeTree(DTBUSINESS,(STATIONID, LINEID, DIRECTION, DTKPI, KPI),8192)'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE kpi_all AS  kpi_local ENGINE = Distributed(perftest_3shards_1replicas, default, kpi_local, rand())'| POST 'http://52.231.190.32:8123/'

echo 'CREATE TABLE transac_local ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTBUSINESS Date,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 )ENGINE = MergeTree(DTBUSINESS,(ID,STATIONIDIN,STATIONIDOUT,DTIN,DTOUT,OCTOPUS,SUBTYPE,TIME),8192)'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE transac_all AS  transac_local ENGINE = Distributed(perftest_3shards_1replicas, default, transac_local, rand())'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE transac_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.190.32:8123/'



####### cat 数据进去
cat /IndepentProjectData/Data/TableReference/postgres_lines/transac_Lines_backup.csv |  time -ao  cluster_load_detele_truncate.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO lines_all FORMAT CSV"
cat /IndepentProjectData/Data/TableReference/postgres_stations/transac_Stations_backup.csv | time -ao  cluster_load_detele_truncate.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01 --query="INSERT INTO stations_all FORMAT CSV"
cat /IndepentProjectData/Data/TableReference/postgres_subtype/transac_SubType_backup.csv | time -ao  cluster_load_detele_truncate.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO subtype_all FORMAT CSV"

echo 'CREATE TABLE kpi_landing (STATIONID String, LINEID String, DIRECTION String, DTKPI String, KPI Int64) ENGINE = TinyLog'| POST 'http://52.231.191.79:8123/'

cat /IndepentProjectData/Data/TableKpi/postgres_kpi/dataKPI_2017_backup.csv | time -ao  cluster_load_detele_truncate.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO kpi_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableKpi/postgres_kpi/dataKPI_2018_backup.csv | time -ao  cluster_load_detele_truncate.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO kpi_landing FORMAT CSV"

echo 'transfer the KPI_landing data from landing to final table'>>  cluster_load_detele_truncate.log
time -ao cluster_load_detele_truncate.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01 --query="INSERT INTO kpi_all
select STATIONID, LINEID, DIRECTION, DTKPI,toDate(substring(toString(DTKPI),1,10)) as DTBUSINESS, KPI from kpi_landing"


echo 'load transac all ---1-12th--- month data to default.database'>> cluster_load_detele_truncate.log
cat /IndepentProjectData/Data/TableTransac/datatransac_201701_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201702_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201703_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201704_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201705_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201706_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201707_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201708_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201709_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201710_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201711_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201712_backup.csv | time -ao cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01  --query="INSERT INTO transac_landing FORMAT CSV"

echo 'transfer the ---1-12th--- TRANSAC_landing data TRANSAC table'>>  cluster_load_detele_truncate.log
time -ao  cluster_load_detele_truncate.log clickhouse-client --host  52.231.191.79 --port 9000 --user admin --password admin01 --query="INSERT INTO  transac_all
select ID,
STATIONIDIN,
STATIONIDOUT,
DTIN,
toDate(substring(toString(DTIN),1,10)) as DTBUSINESS,
DTOUT,
OCTOPUS,
SUBTYPE,
TIME
from  transac_landing"


date >> cluster_load_detele_truncate.log
echo 'test-6.1-6.2-load delete and truncate  ----- stop -----'>> cluster_load_detele_truncate.log



