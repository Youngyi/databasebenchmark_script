#性能测试 6.1-6.2
echo 'default.6.1-6.2-load delete and truncate  ----- start -----'>> cluster_load_detele_truncate.log 
date >> cluster_load_detele_truncate.log
# clusters_vm1_vm2_vm3_create_table
#---------------  server 控制中心 or client 
# echo ''| POST 'http://127.0.0.1:8123/'

# echo 'CREATE TABLE stations_local (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE stations_all AS  stations_local ENGINE = Distributed(perftest_3shards_1replicas, default,  stations_local, rand())'| POST 'http://127.0.0.1:8123/'

# echo 'CREATE TABLE lines_local (LINEID String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE lines_all AS  lines_local ENGINE = Distributed(perftest_3shards_1replicas, default,  lines_local, rand())'| POST 'http://127.0.0.1:8123/'

# echo 'CREATE TABLE subtype_local (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE subtype_all AS subtype_local ENGINE = Distributed(perftest_3shards_1replicas, default,  subtype_local, rand())'| POST 'http://127.0.0.1:8123/'

# echo 'CREATE TABLE kpi_local (STATIONID String, LINEID String, DIRECTION String, DTKPI Datetime, DTBUSINESS Date, KPI Int64) ENGINE = MergeTree(DTBUSINESS,(STATIONID, LINEID, DIRECTION, DTKPI, KPI),8192)'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE kpi_all AS  kpi_local ENGINE = Distributed(perftest_3shards_1replicas, default, kpi_local, rand())'| POST 'http://127.0.0.1:8123/'

# echo 'CREATE TABLE transac_local ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTBUSINESS Date,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 )ENGINE = MergeTree(DTBUSINESS,(ID,STATIONIDIN,STATIONIDOUT,DTIN,DTOUT,OCTOPUS,SUBTYPE,TIME),8192)'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE transac_all AS  transac_local ENGINE = Distributed(perftest_3shards_1replicas, default, transac_local, rand())'| POST 'http://127.0.0.1:8123/'
# echo 'CREATE TABLE transac_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://127.0.0.1:8123/'

#---------------    vm1
# clusters_vm1_vm2_vm3_create_table
# echo ''| POST 'http://52.231.186.4:8123/'

echo 'CREATE  DATABASE  IF  NOT  EXISTS  default'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE stations_local (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE stations_all AS  stations_local ENGINE = Distributed(perftest_3shards_1replicas, default,  stations_local, rand())'| POST 'http://52.231.186.4:8123/'

echo 'CREATE TABLE lines_local (LINEID String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE lines_all AS  lines_local ENGINE = Distributed(perftest_3shards_1replicas, default,  lines_local, rand())'| POST 'http://52.231.186.4:8123/'

echo 'CREATE TABLE subtype_local (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE subtype_all AS subtype_local ENGINE = Distributed(perftest_3shards_1replicas, default,  subtype_local, rand())'| POST 'http://52.231.186.4:8123/'

echo 'CREATE TABLE kpi_local (STATIONID String, LINEID String, DIRECTION String, DTKPI Datetime, DTBUSINESS Date, KPI Int64) ENGINE = MergeTree(DTBUSINESS,(STATIONID, LINEID, DIRECTION, DTKPI, KPI),8192)'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE kpi_all AS  kpi_local ENGINE = Distributed(perftest_3shards_1replicas, default, kpi_local, rand())'| POST 'http://52.231.186.4:8123/'

echo 'CREATE TABLE transac_local ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTBUSINESS Date,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 )ENGINE = MergeTree(DTBUSINESS,(ID,STATIONIDIN,STATIONIDOUT,DTIN,DTOUT,OCTOPUS,SUBTYPE,TIME),8192)'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE transac_all AS  transac_local ENGINE = Distributed(perftest_3shards_1replicas, default, transac_local, rand())'| POST 'http://52.231.186.4:8123/'
echo 'CREATE TABLE transac_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.4:8123/'

#---------------    vm2
# clusters_vm1_vm2_vm3_create_table
# echo ''| POST 'http://52.231.191.79:8123/'
echo 'CREATE  DATABASE  IF  NOT  EXISTS  default'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE stations_local (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE stations_all AS  stations_local ENGINE = Distributed(perftest_3shards_1replicas, default,  stations_local, rand())'| POST 'http://52.231.191.79:8123/'

echo 'CREATE TABLE lines_local (LINEID String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE lines_all AS  lines_local ENGINE = Distributed(perftest_3shards_1replicas, default,  lines_local, rand())'| POST 'http://52.231.191.79:8123/'

echo 'CREATE TABLE subtype_local (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE subtype_all AS subtype_local ENGINE = Distributed(perftest_3shards_1replicas, default,  subtype_local, rand())'| POST 'http://52.231.191.79:8123/'

echo 'CREATE TABLE kpi_local (STATIONID String, LINEID String, DIRECTION String, DTKPI Datetime, DTBUSINESS Date, KPI Int64) ENGINE = MergeTree(DTBUSINESS,(STATIONID, LINEID, DIRECTION, DTKPI, KPI),8192)'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE kpi_all AS  kpi_local ENGINE = Distributed(perftest_3shards_1replicas, default, kpi_local, rand())'| POST 'http://52.231.191.79:8123/'

echo 'CREATE TABLE transac_local ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTBUSINESS Date,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 )ENGINE = MergeTree(DTBUSINESS,(ID,STATIONIDIN,STATIONIDOUT,DTIN,DTOUT,OCTOPUS,SUBTYPE,TIME),8192)'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE transac_all AS  transac_local ENGINE = Distributed(perftest_3shards_1replicas, default, transac_local, rand())'| POST 'http://52.231.191.79:8123/'
echo 'CREATE TABLE transac_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.191.79:8123/'


#---------------    vm
# clusters_vm1_vm2_vm3_create_table
# echo ''| POST 'http://52.231.186.4:8123/'
echo 'CREATE  DATABASE  IF  NOT  EXISTS  default'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE stations_local (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE stations_all AS  stations_local ENGINE = Distributed(perftest_3shards_1replicas, default,  stations_local, rand())'| POST 'http://52.231.190.32:8123/'

echo 'CREATE TABLE lines_local (LINEID String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE lines_all AS  lines_local ENGINE = Distributed(perftest_3shards_1replicas, default,  lines_local, rand())'| POST 'http://52.231.190.32:8123/'

echo 'CREATE TABLE subtype_local (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE subtype_all AS subtype_local ENGINE = Distributed(perftest_3shards_1replicas, default,  subtype_local, rand())'| POST 'http://52.231.190.32:8123/'

echo 'CREATE TABLE kpi_local (STATIONID String, LINEID String, DIRECTION String, DTKPI Datetime, DTBUSINESS Date, KPI Int64) ENGINE = MergeTree(DTBUSINESS,(STATIONID, LINEID, DIRECTION, DTKPI, KPI),8192)'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE kpi_all AS  kpi_local ENGINE = Distributed(perftest_3shards_1replicas, default, kpi_local, rand())'| POST 'http://52.231.190.32:8123/'

echo 'CREATE TABLE transac_local ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTBUSINESS Date,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 )ENGINE = MergeTree(DTBUSINESS,(ID,STATIONIDIN,STATIONIDOUT,DTIN,DTOUT,OCTOPUS,SUBTYPE,TIME),8192)'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE transac_all AS  transac_local ENGINE = Distributed(perftest_3shards_1replicas, default, transac_local, rand())'| POST 'http://52.231.190.32:8123/'
echo 'CREATE TABLE transac_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.190.32:8123/'


