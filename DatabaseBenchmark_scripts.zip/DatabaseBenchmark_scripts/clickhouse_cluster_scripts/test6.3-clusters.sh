# default..3-cluster.sh
echo 'Clickhouse-client default.queries START--------------------'>> test6.3-cluster.log 
# echo '# without cache'>> test6.3-cluster.log 
# echo '# with cache 2th'>> test6.3-cluster.log 
# echo '# with cache 3th'>> test6.3-cluster.log 
date >> test6.3-cluster.log 



echo '# 1- Count ID'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT from  transac_all;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT from  transac_all;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT from  transac_all;"



echo '# 2- Count distinct ID'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query='Select count(distinct ID) as CNTD from  transac_all;'
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query='Select count(distinct ID) as CNTD from  transac_all;'
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query='Select count(distinct ID) as CNTD from  transac_all;'

echo '# 3-Count distinct ID and Count ID and AVG time'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT,count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT,count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT,count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all;"

echo '# 4- with Group by 1 field'>> time -ao test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN, count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all GROUP BY STATIONIDIN SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN, count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all GROUP BY STATIONIDIN SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN, count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all GROUP BY STATIONIDIN SETTINGS max_bytes_before_external_group_by = 5000000000;"


echo '# 5- (3 indic) with Group by 3 field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN, STATIONIDOUT, OCTOPUS, count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN, STATIONIDOUT, OCTOPUS, count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN, STATIONIDOUT, OCTOPUS, count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# 6- (3 indic) with Group by multiple fields and joins 3 tables'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="SELECT LINEINDESC,LINEOUTDESC,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT LINEINDESC,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT LINEIDIN,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT LINEIDIN,STATIONIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME,STATIONIDIN,STATIONIDOUT FROM(SELECT t.STATIONIDIN AS STATIONIDIN,t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS,t.SUBTYPE AS SUBTYPEID,count(t.ID) as CNT,count(distinct t.ID) as CNTD,AVG(t.TIME) as AVGTIME FROM transac_all t GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE) ANY LEFT JOIN (SELECT SUBTYPEID, SUBTYPEDESC FROM default.SUBTYPE)USING (SUBTYPEID)) ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM default.stations_all)USING(STATIONIDIN)) ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM default.stations_all)USING(STATIONIDOUT)) ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM default.lines_all)USING(LINEIDIN)) ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM default.lines_all)USING(LINEIDOUT) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="SELECT LINEINDESC,LINEOUTDESC,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT LINEINDESC,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT LINEIDIN,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT LINEIDIN,STATIONIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME,STATIONIDIN,STATIONIDOUT FROM(SELECT t.STATIONIDIN AS STATIONIDIN,t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS,t.SUBTYPE AS SUBTYPEID,count(t.ID) as CNT,count(distinct t.ID) as CNTD,AVG(t.TIME) as AVGTIME FROM transac_all t GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE) ANY LEFT JOIN (SELECT SUBTYPEID, SUBTYPEDESC FROM default.SUBTYPE)USING (SUBTYPEID)) ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM default.stations_all)USING(STATIONIDIN)) ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM default.stations_all)USING(STATIONIDOUT)) ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM default.lines_all)USING(LINEIDIN)) ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM default.lines_all)USING(LINEIDOUT) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="SELECT LINEINDESC,LINEOUTDESC,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT LINEINDESC,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT LINEIDIN,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT LINEIDIN,STATIONIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME FROM(SELECT OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME,STATIONIDIN,STATIONIDOUT FROM(SELECT t.STATIONIDIN AS STATIONIDIN,t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS,t.SUBTYPE AS SUBTYPEID,count(t.ID) as CNT,count(distinct t.ID) as CNTD,AVG(t.TIME) as AVGTIME FROM transac_all t GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE) ANY LEFT JOIN (SELECT SUBTYPEID, SUBTYPEDESC FROM default.SUBTYPE)USING (SUBTYPEID)) ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM default.stations_all)USING(STATIONIDIN)) ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM default.stations_all)USING(STATIONIDOUT)) ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM default.lines_all)USING(LINEIDIN)) ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM default.lines_all)USING(LINEIDOUT) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# 7- (3 indic) with Group by 1 datetime binning formula'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log  clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select toStartOfFifteenMinutes(DTIN) as DTIN15MIN,count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from transac_all GROUP BY DTIN15MIN  SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log  clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select toStartOfFifteenMinutes(DTIN) as DTIN15MIN,count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from transac_all GROUP BY DTIN15MIN  SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log  clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select toStartOfFifteenMinutes(DTIN) as DTIN15MIN,count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from transac_all GROUP BY DTIN15MIN  SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# 8- (3 indic) + AVG KPI with Group by multiple fields and joins 2 tables plus KPI table'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log  clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
( SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, DTIN AS TIMEIN,count(ID) as CNT, count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
FROM transac_all GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN ) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM stations_all) ANY LEFT JOIN
(SELECT LINEID FROM lines_all)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log  clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
( SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, DTIN AS TIMEIN,count(ID) as CNT, count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
FROM transac_all GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN ) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM stations_all) ANY LEFT JOIN
(SELECT LINEID FROM lines_all)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log  clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
( SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, DTIN AS TIMEIN,count(ID) as CNT, count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
FROM transac_all GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN ) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION 
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM stations_all) ANY LEFT JOIN
(SELECT LINEID FROM lines_all)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# 9- (3 indic) with filter on the partition field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from  transac_all where DTBUSINESS >= toDate('2017-11-01');"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from  transac_all where DTBUSINESS >= toDate('2017-11-01');"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from  transac_all where DTBUSINESS >= toDate('2017-11-01');"

echo '# 10- (3 indic) with Group by 1 field with filter on the partition field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all where DTIN >= toDate('2017-11-01') GROUP BY STATIONIDIN SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all where DTIN >= toDate('2017-11-01') GROUP BY STATIONIDIN SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all where DTIN >= toDate('2017-11-01') GROUP BY STATIONIDIN SETTINGS max_bytes_before_external_group_by = 5000000000;"


echo '# 11- (3 indic) with Group by 3 field with filter on the partition field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all where DTBUSINESS >= toDate('2017-11-01') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all where DTBUSINESS >= toDate('2017-11-01') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  transac_all where DTBUSINESS >= toDate('2017-11-01') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"

echo '# 12- (3 indic) with Group by multiple fields and joins 3 tables with filter on the partition field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="SELECT LINEINDESC,LINEOUTDESC, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEINDESC, LINEIDOUT,OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,LINEIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,STATIONIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM ( SELECT OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME,STATIONIDIN,STATIONIDOUT FROM (SELECT t.STATIONIDIN AS STATIONIDIN, t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS, t.SUBTYPE AS SUBTYPEID, count(t.ID) as CNT, count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME FROM transac_all t WHERE t.DTBUSINESS >= toDate('2017-11-01') GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE )ANY LEFT JOIN ( SELECT SUBTYPEID, SUBTYPEDESC FROM SUBTYPE)USING (SUBTYPEID))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM stations_all )USING(STATIONIDIN))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM stations_all )USING(STATIONIDOUT))ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM lines_all )USING(LINEIDIN))ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM lines_all )USING(LINEIDOUT);"
echo '# with cache 2th'>> test6.3-cluster.log
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="SELECT LINEINDESC,LINEOUTDESC, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEINDESC, LINEIDOUT,OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,LINEIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,STATIONIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM ( SELECT OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME,STATIONIDIN,STATIONIDOUT FROM (SELECT t.STATIONIDIN AS STATIONIDIN, t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS, t.SUBTYPE AS SUBTYPEID, count(t.ID) as CNT, count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME FROM transac_all t WHERE t.DTBUSINESS >= toDate('2017-11-01') GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE )ANY LEFT JOIN ( SELECT SUBTYPEID, SUBTYPEDESC FROM SUBTYPE)USING (SUBTYPEID))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM stations_all )USING(STATIONIDIN))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM stations_all )USING(STATIONIDOUT))ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM lines_all )USING(LINEIDIN))ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM lines_all )USING(LINEIDOUT);" 
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="SELECT LINEINDESC,LINEOUTDESC, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEINDESC, LINEIDOUT,OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,LINEIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,STATIONIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM ( SELECT OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME,STATIONIDIN,STATIONIDOUT FROM (SELECT t.STATIONIDIN AS STATIONIDIN, t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS, t.SUBTYPE AS SUBTYPEID, count(t.ID) as CNT, count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME FROM transac_all t WHERE t.DTBUSINESS >= toDate('2017-11-01') GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE )ANY LEFT JOIN ( SELECT SUBTYPEID, SUBTYPEDESC FROM SUBTYPE)USING (SUBTYPEID))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM stations_all )USING(STATIONIDIN))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM stations_all )USING(STATIONIDOUT))ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM lines_all )USING(LINEIDIN))ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM lines_all )USING(LINEIDOUT);" 

echo '# 13- (3 indic) with Group by 1 datetime binning formula with filter on the partition field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
Select
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from transac_all
where DTBUSINESS >= toDate('2017-11-01') GROUP BY
toStartOfFifteenMinutes(DTIN);"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
Select
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from transac_all
where DTBUSINESS >= toDate('2017-11-01') GROUP BY
toStartOfFifteenMinutes(DTIN);"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
Select
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from transac_all
where DTBUSINESS >= toDate('2017-11-01') GROUP BY
toStartOfFifteenMinutes(DTIN);"

echo '# 14- (3 indic) + AVG KPI with Group by multiple fields and joins 2 tables plus KPI table with filter on the partition field of transaction table'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM 
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI 
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME 
FROM transac_all
WHERE DTBUSINESS >= toDate('2017-11-01')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as
SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION 
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM stations_all) ANY LEFT JOIN
(SELECT LINEID FROM lines_all)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM 
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI 
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME 
FROM transac_all
WHERE DTBUSINESS >= toDate('2017-11-01')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as
SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM stations_all) ANY LEFT JOIN
(SELECT LINEID FROM lines_all)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM 
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI 
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME 
FROM transac_all
WHERE DTBUSINESS >= toDate('2017-11-01')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as
SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM stations_all) ANY LEFT JOIN
(SELECT LINEID FROM lines_all)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# 15- (3 indic) with filter on non-partition field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from transac_all where SUBTYPE in ('AVUP', 'PNQI');"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from transac_all where SUBTYPE in ('AVUP', 'PNQI');"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from transac_all where SUBTYPE in ('AVUP', 'PNQI');"


echo '# 16- (3 indic) with Group by 1 field with filter on non-partition field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from transac_all where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from transac_all where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from transac_all where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN SETTINGS  max_bytes_before_external_group_by = 5000000000;"

echo '# 17- (3 indic) with Group by 3 field with filter on non-partition field'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from transac_all where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from transac_all where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from transac_all where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from transac_all where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"

echo '# 18- (3 indic) with Group by multiple fields and joins 3 tables with filter on non-partition field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT LINEINDESC,LINEOUTDESC,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME 
FROM(SELECT LINEINDESC,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,STATIONIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME,STATIONIDIN,STATIONIDOUT
FROM(SELECT t.STATIONIDIN AS STATIONIDIN,t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS,t.SUBTYPE AS SUBTYPEID,count(t.ID) as CNT,count(distinct t.ID) as CNTD,AVG(t.TIME) as AVGTIME
FROM transac_all t where t.SUBTYPE in ('AVUP', 'PNQI') 
GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE 
)ANY LEFT JOIN (SELECT SUBTYPEID, SUBTYPEDESC FROM default.SUBTYPE)USING (SUBTYPEID)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM default.stations_all)USING(STATIONIDIN)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM default.stations_all)USING(STATIONIDOUT)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM default.lines_all)USING(LINEIDIN)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM default.lines_all)USING(LINEIDOUT) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="SELECT LINEINDESC,LINEOUTDESC,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME 
FROM(SELECT LINEINDESC,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,STATIONIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME,STATIONIDIN,STATIONIDOUT
FROM(SELECT t.STATIONIDIN AS STATIONIDIN,t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS,t.SUBTYPE AS SUBTYPEID,count(t.ID) as CNT,count(distinct t.ID) as CNTD,AVG(t.TIME) as AVGTIME
FROM transac_all t where t.SUBTYPE in ('AVUP', 'PNQI') 
GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE 
)ANY LEFT JOIN (SELECT SUBTYPEID, SUBTYPEDESC FROM default.SUBTYPE)USING (SUBTYPEID)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM default.stations_all)USING(STATIONIDIN)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM default.stations_all)USING(STATIONIDOUT)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM default.lines_all)USING(LINEIDIN)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM default.lines_all)USING(LINEIDOUT) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="SELECT LINEINDESC,LINEOUTDESC,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME 
FROM(SELECT LINEINDESC,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,STATIONIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME,STATIONIDIN,STATIONIDOUT
FROM(SELECT t.STATIONIDIN AS STATIONIDIN,t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS,t.SUBTYPE AS SUBTYPEID,count(t.ID) as CNT,count(distinct t.ID) as CNTD,AVG(t.TIME) as AVGTIME
FROM transac_all t where t.SUBTYPE in ('AVUP', 'PNQI') 
GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE 
)ANY LEFT JOIN (SELECT SUBTYPEID, SUBTYPEDESC FROM default.SUBTYPE)USING (SUBTYPEID)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM default.stations_all)USING(STATIONIDIN)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM default.stations_all)USING(STATIONIDOUT)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM default.lines_all)USING(LINEIDIN)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM default.lines_all)USING(LINEIDOUT) SETTINGS max_bytes_before_external_group_by = 5000000000;"


echo '# 19-  (3 indic) with Group by 1 datetime binning formula with filter on non-partition field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from transac_all
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY toStartOfFifteenMinutes(DTIN) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from transac_all
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY toStartOfFifteenMinutes(DTIN) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from transac_all
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY toStartOfFifteenMinutes(DTIN) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# 20- (3 indic) + AVG KPI with Group by multiple fields and joins 2 tables plus KPI table with filter on non-partition field'>> test6.3-cluster.log 
echo '# without cache'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD, AVG(TIME) as AVGTIME 
FROM transac_all
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN 
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION 
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM stations_all) ANY LEFT JOIN
(SELECT LINEID FROM lines_all)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD, AVG(TIME) as AVGTIME 
FROM transac_all
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN 
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION 
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM stations_all) ANY LEFT JOIN
(SELECT LINEID FROM lines_all)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test6.3-cluster.log 
time -ao test6.3-cluster.log clickhouse-client --host 52.231.191.79 --port 9000 --user admin --password admin01  --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD, AVG(TIME) as AVGTIME 
FROM transac_all
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN 
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM stations_all) ANY LEFT JOIN
(SELECT LINEID FROM lines_all)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"


echo 'Clickhouse-client default.queries STOP--------------------'>> test6.3-cluster.log 
date >> test6.3-cluster.log 
