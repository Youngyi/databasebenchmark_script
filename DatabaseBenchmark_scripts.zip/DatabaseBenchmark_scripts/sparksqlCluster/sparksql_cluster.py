from pyspark.sql import SparkSession
from pyspark.conf import SparkConf
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.sql.types import *
import time
"""
sc = SparkContext()
sqlContext=SQLContext(sc)
sqlContext.read.format('com.databricks.spark.csv').options(header='true', inferschema='true').load('game-clicks.csv')
"""
start = time.time()
print("**************** testing start ********************")
print(start)

#sdf=sqlc.createDataFrame(df)
conf=SparkConf()
conf.setMaster("spark://10.0.0.8:7077")
conf.setAppName("test application")
sc=SparkContext(conf=conf)
sqlContext = SQLContext(sc)
kpi_schema = StructType([
    StructField("STATIONID", StringType()),
    StructField("LINED", StringType()),
    StructField("DIRECTION", StringType()),
    StructField("DTKPI", StringType()),
    StructField("KPI", IntegerType())
])

kpi_df = sqlContext.read \
    .schema(kpi_schema) \
    .option("header", "false") \
    .option("mode", "DROPMALFORMED") \
    .csv(["hdfs://10.0.0.8:9002/KPI_2017.csv", "hdfs://10.0.0.8:9002/KPI_2018.csv"])

transac_schema = StructType([
    StructField("ID", IntegerType()),
    StructField("STATIONIDIN", StringType()),
    StructField("STATIONIDOUT", StringType()),
    StructField("DTIN", TimestampType()),
    StructField("DTOUT", TimestampType()),
    StructField("OCTOPUS", StringType()),
    StructField("SUBTYPE", StringType()),
    StructField("TIME", IntegerType())
])

path_list = []
for month in range(1, 13):
    month_str = str(month).zfill(2)
    path = "hdfs://10.0.0.8:9002/datatransac_2017{}_backup.csv".format(month_str)
    path_list.append(path)
path_list.append("hdfs://10.0.0.8:9002/datatransac_201801_backup.csv")

transac_df = sqlContext.read \
    .schema(transac_schema) \
    .option("header", "false") \
    .option("mode", "DROPMALFORMED") \
    .csv(path_list)

stations_schema = StructType([
    StructField("STATIONID", StringType()),
    StructField("STATIONDESC", StringType()),
    StructField("MAINLINEID", StringType()),
])

stations_df = sqlContext.read \
    .schema(transac_schema) \
    .option("header", "false") \
    .option("mode", "DROPMALFORMED") \
    .csv("hdfs://10.0.0.8:9002/transac_Stations_backup.csv")

lines_schema = StructType([
    StructField("LINEID", StringType()),
    StructField("LINEDESC", StringType()),
    StructField("LINECOLOR", StringType()),
])
lines_df = sqlContext.read \
    .schema(transac_schema) \
    .option("header", "false") \
    .option("mode", "DROPMALFORMED") \
    .csv("hdfs://10.0.0.8:9002/transac_Lines_backup.csv")
subtypes_schema = StructType([
    StructField("SUBTYPEID", StringType()),
    StructField("SUBTYPEDESC", StringType()),
])

subtypes_df = sqlContext.read \
    .schema(transac_schema) \
    .option("header", "false") \
    .option("mode", "DROPMALFORMED") \
    .csv("hdfs://10.0.0.8:9002/transac_SubType_backup.csv")

sqlContext.registerDataFrameAsTable(kpi_df, "KPI")
sqlContext.registerDataFrameAsTable(transac_df, "TRANSAC")
sqlContext.registerDataFrameAsTable(subtypes_df, "SUBTYPE")
sqlContext.registerDataFrameAsTable(lines_df, "LINES")
sqlContext.registerDataFrameAsTable(stations_df, "STATIONS")

test_df = sqlContext.sql("Select STATIONIDIN,STATIONIDOUT,OCTOPUS,count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from TRANSAC GROUP BY STATIONIDIN, STATIONIDOUT,OCTOPUS").show()

end = time.time()
print(end-start)