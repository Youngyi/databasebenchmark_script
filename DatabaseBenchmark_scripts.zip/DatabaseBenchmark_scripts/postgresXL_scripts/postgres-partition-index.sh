## echo 'postgres_partition_index_triggles  ----- start -----'>> postgres_partition_index_triggles.log
# drop table transac_y2017m01;
# drop table transac_y2017m02;
# drop table transac_y2017m03;
# drop table transac_y2017m04;
# drop table transac_y2017m05;
# drop table transac_y2017m06;
# drop table transac_y2017m07;
# drop table transac_y2017m08;
# drop table transac_y2017m09;
# drop table transac_y2017m10;
# drop table transac_y2017m11;
# drop table transac_y2017m12;
# drop table transac_y2018m02;
# drop table transac;

# drop table KPI_y2017m01;
# drop table KPI_y2017m02;
# drop table KPI_y2017m03;
# drop table KPI_y2017m04;
# drop table KPI_y2017m05;
# drop table KPI_y2017m06;
# drop table KPI_y2017m07;
# drop table KPI_y2017m08;
# drop table KPI_y2017m09;
# drop table KPI_y2017m10;
# drop table KPI_y2017m11;
# drop table KPI_y2017m12;
# drop table KPI_y2018m02;
# drop table KPI;


#--------------- creat partition tables
CREATE TABLE transac (
    ID bigint  NOT NULL,
    STATIONIDIN char (3) NOT NULL,
    STATIONIDOUT char (3) NOT NULL,
    DTIN varchar,
    DTBUSINESS date,
    DTOUT timestamp,
    OCTOPUS char (1) NOT NULL,
    SUBTYPE char (4) NOT NULL,
    TIME int
);

CREATE TABLE kpi (
    STATIONID char (3) NOT NULL,
    LINEID char (6) NOT NULL,
    DIRECTION char (1) NOT NULL,
    DTKPI varchar,
    DTBUSINESS date,
    KPI int
);

create table transac_y2017m01 ( check(dtbusiness>=DATE'2017-01-01' and dtbusiness<DATE'2017-02-01'))inherits(transac);
create table KPI_y2017m01 ( check(dtbusiness>=DATE'2017-01-01' and dtbusiness<DATE'2017-02-01'))inherits(kpi);

create table transac_y2017m02 ( check(dtbusiness>=DATE'2017-02-01' and dtbusiness<DATE'2017-03-01'))inherits(transac);
create table KPI_y2017m02 ( check(dtbusiness>=DATE'2017-02-01' and dtbusiness<DATE'2017-03-01'))inherits(kpi);

create table transac_y2017m03 ( check(dtbusiness>=DATE'2017-03-01' and dtbusiness<DATE'2017-04-01'))inherits(transac);
create table KPI_y2017m03 ( check(dtbusiness>=DATE'2017-03-01' and dtbusiness<DATE'2017-04-01'))inherits(kpi);

create table transac_y2017m04 ( check(dtbusiness>=DATE'2017-04-01' and dtbusiness<DATE'2017-05-01'))inherits(transac);
create table KPI_y2017m04 ( check(dtbusiness>=DATE'2017-04-01' and dtbusiness<DATE'2017-05-01'))inherits(kpi);

create table transac_y2017m05 ( check(dtbusiness>=DATE'2017-05-01' and dtbusiness<DATE'2017-06-01'))inherits(transac);
create table KPI_y2017m05 ( check(dtbusiness>=DATE'2017-05-01' and dtbusiness<DATE'2017-06-01'))inherits(kpi);

create table transac_y2017m06 ( check(dtbusiness>=DATE'2017-06-01' and dtbusiness<DATE'2017-07-01'))inherits(transac);
create table KPI_y2017m06 ( check(dtbusiness>=DATE'2017-06-01' and dtbusiness<DATE'2017-07-01'))inherits(kpi);

create table transac_y2017m07 ( check(dtbusiness>=DATE'2017-07-01' and dtbusiness<DATE'2017-08-01'))inherits(transac);
create table KPI_y2017m07 ( check(dtbusiness>=DATE'2017-07-01' and dtbusiness<DATE'2017-08-01'))inherits(kpi);

create table transac_y2017m08 ( check(dtbusiness>=DATE'2017-08-01' and dtbusiness<DATE'2017-09-01'))inherits(transac);
create table KPI_y2017m08 ( check(dtbusiness>=DATE'2017-08-01' and dtbusiness<DATE'2017-09-01'))inherits(kpi);

create table transac_y2017m09 ( check(dtbusiness>=DATE'2017-09-01' and dtbusiness<DATE'2017-10-01'))inherits(transac);
create table KPI_y2017m09 ( check(dtbusiness>=DATE'2017-09-01' and dtbusiness<DATE'2017-10-01'))inherits(kpi);

create table transac_y2017m10 ( check(dtbusiness>=DATE'2017-10-01' and dtbusiness<DATE'2017-11-01'))inherits(transac);
create table KPI_y2017m10 ( check(dtbusiness>=DATE'2017-10-01' and dtbusiness<DATE'2017-11-01'))inherits(kpi);

create table transac_y2017m11 ( check(dtbusiness>=DATE'2017-11-01' and dtbusiness<DATE'2017-12-01'))inherits(transac);
create table KPI_y2017m11 ( check(dtbusiness>=DATE'2017-11-01' and dtbusiness<DATE'2017-12-01'))inherits(kpi);

create table transac_y2017m12 ( check(dtbusiness>=DATE'2017-12-01' and dtbusiness<DATE'2018-01-01'))inherits(transac);
create table KPI_y2017m12 ( check(dtbusiness>=DATE'2017-12-01' and dtbusiness<DATE'2018-01-01'))inherits(kpi);

create table transac_y2018m02 ( check(dtbusiness>=DATE'2018-01-01' and dtbusiness<DATE'2017-02-01'))inherits(transac);
create table KPI_y2018m02 ( check(dtbusiness>=DATE'2018-01-01' and dtbusiness<DATE'2018-02-01'))inherits(kpi);

#--------------- creat indexs
CREATE INDEX transac_y2017m01_DTBUSINESS ON  transac_y2017m01 (DTBUSINESS);
CREATE INDEX transac_y2017m01_01 ON  transac_y2017m01 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m01_DTBUSINESS ON  KPI_y2017m01 (DTBUSINESS);

CREATE INDEX transac_y2017m02_DTBUSINESS ON  transac_y2017m02 (DTBUSINESS);
CREATE INDEX transac_y2017m02_01 ON  transac_y2017m02 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m02_DTBUSINESS ON  KPI_y2017m02 (DTBUSINESS);

CREATE INDEX transac_y2017m03_DTBUSINESS ON  transac_y2017m03 (DTBUSINESS);
CREATE INDEX transac_y2017m03_01 ON  transac_y2017m03 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m03_DTBUSINESS ON  KPI_y2017m03 (DTBUSINESS);

CREATE INDEX transac_y2017m04_DTBUSINESS ON  transac_y2017m04 (DTBUSINESS);
CREATE INDEX transac_y2017m04_01 ON  transac_y2017m04 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m04_DTBUSINESS ON  KPI_y2017m04 (DTBUSINESS);

CREATE INDEX transac_y2017m05_DTBUSINESS ON  transac_y2017m05 (DTBUSINESS);
CREATE INDEX transac_y2017m05_01 ON  transac_y2017m05 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m05_DTBUSINESS ON  KPI_y2017m05 (DTBUSINESS);

CREATE INDEX transac_y2017m06_DTBUSINESS ON  transac_y2017m06 (DTBUSINESS);
CREATE INDEX transac_y2017m06_01 ON  transac_y2017m06 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m06_DTBUSINESS ON  KPI_y2017m06 (DTBUSINESS);

CREATE INDEX transac_y2017m07_DTBUSINESS ON  transac_y2017m07 (DTBUSINESS);
CREATE INDEX transac_y2017m07_01 ON  transac_y2017m07 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m07_DTBUSINESS ON  KPI_y2017m07 (DTBUSINESS);

CREATE INDEX transac_y2017m08_DTBUSINESS ON  transac_y2017m08 (DTBUSINESS);
CREATE INDEX transac_y2017m08_01 ON  transac_y2017m08 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m08_DTBUSINESS ON  KPI_y2017m08 (DTBUSINESS);

CREATE INDEX transac_y2017m09_DTBUSINESS ON  transac_y2017m09 (DTBUSINESS);
CREATE INDEX transac_y2017m09_01 ON  transac_y2017m09 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m09_DTBUSINESS ON  KPI_y2017m09 (DTBUSINESS);

CREATE INDEX transac_y2017m10_DTBUSINESS ON  transac_y2017m10 (DTBUSINESS);
CREATE INDEX transac_y2017m10_01 ON  transac_y2017m10 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m10_DTBUSINESS ON  KPI_y2017m10 (DTBUSINESS);

CREATE INDEX transac_y2017m11_DTBUSINESS ON  transac_y2017m11 (DTBUSINESS);
CREATE INDEX transac_y2017m11_01 ON  transac_y2017m11 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m11_DTBUSINESS ON  KPI_y2017m11 (DTBUSINESS);

CREATE INDEX transac_y2017m12_DTBUSINESS ON  transac_y2017m12 (DTBUSINESS);
CREATE INDEX transac_y2017m12_01 ON  transac_y2017m12 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m12_DTBUSINESS ON  KPI_y2017m12 (DTBUSINESS);

CREATE INDEX transac_y2018m02_DTBUSINESS ON  transac_y2018m02 (DTBUSINESS);
CREATE INDEX transac_y2018m02_01 ON  transac_y2018m02 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2018m02_DTBUSINESS ON  KPI_y2018m02 (DTBUSINESS);

#--------------- creat triggles_transac
CREATE OR REPLACE FUNCTION transac_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF ( NEW.DTBUSINESS >= DATE '2017-01-01'  AND
         NEW.DTBUSINESS < DATE '2017-02-01' ) THEN
        INSERT INTO transac_y2017m01 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-02-01' AND
            NEW.DTBUSINESS < DATE '2017-03-01' ) THEN
        INSERT INTO transac_y2017m02 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-03-01' AND
            NEW.DTBUSINESS < DATE '2017-04-01' ) THEN
        INSERT INTO transac_y2017m03 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-04-01' AND
            NEW.DTBUSINESS < DATE '2017-05-01' ) THEN
        INSERT INTO transac_y2017m04 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-05-01' AND
            NEW.DTBUSINESS < DATE '2017-06-01' ) THEN
        INSERT INTO transac_y2017m05 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-06-01' AND
            NEW.DTBUSINESS < DATE '2017-07-01' ) THEN
        INSERT INTO transac_y2017m06 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-07-01' AND
            NEW.DTBUSINESS < DATE '2017-08-01' ) THEN
        INSERT INTO transac_y2017m07 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-08-01' AND
            NEW.DTBUSINESS < DATE '2017-09-01' ) THEN
        INSERT INTO transac_y2017m08 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-09-01' AND
            NEW.DTBUSINESS < DATE '2017-10-01' ) THEN
        INSERT INTO transac_y2017m09 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-10-01' AND
            NEW.DTBUSINESS < DATE '2017-11-01' ) THEN
        INSERT INTO transac_y2017m10 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-11-01' AND
            NEW.DTBUSINESS < DATE '2017-12-01' ) THEN
        INSERT INTO transac_y2017m11 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-12-01' AND
            NEW.DTBUSINESS < DATE '2018-01-01' ) THEN
        INSERT INTO transac_y2017m12 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2018-01-01' AND
            NEW.DTBUSINESS < DATE '2018-02-01' ) THEN
        INSERT INTO transac_y2018m02 VALUES (NEW.*);
    ELSE
        RAISE EXCEPTION 'Date out of range.  Fix the measurement_insert_trigger() function!';
    END IF;
    RETURN NULL;
END;
$$
LANGUAGE plpgsql;

#--------------- creat triggles_KPI
CREATE OR REPLACE FUNCTION KPI_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF ( NEW.DTBUSINESS >= DATE '2017-01-01'  AND
         NEW.DTBUSINESS < DATE '2017-02-01' ) THEN
        INSERT INTO KPI_y2017m01 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-02-01' AND
            NEW.DTBUSINESS < DATE '2017-03-01' ) THEN
        INSERT INTO KPI_y2017m02 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-03-01' AND
            NEW.DTBUSINESS < DATE '2017-04-01' ) THEN
        INSERT INTO KPI_y2017m03 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-04-01' AND
            NEW.DTBUSINESS < DATE '2017-05-01' ) THEN
        INSERT INTO KPI_y2017m04 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-05-01' AND
            NEW.DTBUSINESS < DATE '2017-06-01' ) THEN
        INSERT INTO KPI_y2017m05 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-06-01' AND
            NEW.DTBUSINESS < DATE '2017-07-01' ) THEN
        INSERT INTO KPI_y2017m06 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-07-01' AND
            NEW.DTBUSINESS < DATE '2017-08-01' ) THEN
        INSERT INTO KPI_y2017m07 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-08-01' AND
            NEW.DTBUSINESS < DATE '2017-09-01' ) THEN
        INSERT INTO KPI_y2017m08 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-09-01' AND
            NEW.DTBUSINESS < DATE '2017-10-01' ) THEN
        INSERT INTO KPI_y2017m09 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-10-01' AND
            NEW.DTBUSINESS < DATE '2017-11-01' ) THEN
        INSERT INTO KPI_y2017m10 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-11-01' AND
            NEW.DTBUSINESS < DATE '2017-12-01' ) THEN
        INSERT INTO KPI_y2017m11 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2017-12-01' AND
            NEW.DTBUSINESS < DATE '2018-01-01' ) THEN
        INSERT INTO KPI_y2017m12 VALUES (NEW.*);
    ELSIF ( NEW.DTBUSINESS >= DATE '2018-01-01' AND
            NEW.DTBUSINESS < DATE '2018-02-01' ) THEN
        INSERT INTO KPI_y2018m02 VALUES (NEW.*);
    ELSE
        RAISE EXCEPTION 'Date out of range.  Fix the measurement_insert_trigger() function!';
    END IF;
    RETURN NULL;
END;
$$
LANGUAGE plpgsql;

CREATE TRIGGER KPI_insert_trigger
    BEFORE INSERT ON kpi
    FOR EACH ROW EXECUTE PROCEDURE KPI_insert_trigger();

CREATE TRIGGER transac_insert_trigger
    BEFORE INSERT ON transac
    FOR EACH ROW EXECUTE PROCEDURE transac_insert_trigger();



INSERT INTO KPI select STATIONID, LINEID, DIRECTION, DTKPI,to_Date(substring(dtkpi from 1 for 10), 'YYYY-MM-DD') as DTBUSINESS, KPI from KPI_landing;
INSERT INTO TRANSAC select ID, STATIONIDIN, STATIONIDOUT, DTIN, to_Date(substring(dtin from 1 for 10), 'YYYY-MM-DD') as DTBUSINESS,DTOUT,OCTOPUS,SUBTYPE,TIME from TRANSAC_landing;

##echo 'postgres_partition_index_triggles  ----- start -----'>> postgres_partition_index_triggles.log