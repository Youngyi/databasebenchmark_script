





vim .bashrc
export PATH=/usr/local/pgsql/bin:$PATH
ssh-keygen -t rsa
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
scp -r .ssh/ es3:
passwd  #这里 密码输入123

pgxc_ctl
vim /home/postgres/pgxc_ctl/pgxc_ctl.conf #下方的配置文件
ifconfig
netstat -ltupn
cd nodes/
rm -rf *
pgxc_ctl init all

root模式下的输入：
useradd -m  postgres
su -  postgres

git clone git://git.postgresql.org/git/postgres-xl.git
cd postgres-xl/
sudo apt-get update && sudo apt-get install build-essential -y && sudo apt-get install zlib1g-dev -y && sudo apt-get install libreadline6 libreadline6-dev -y && sudo apt-get install bison -y && sudo apt-get install flex -y
./configure && make -j

cd /home/postgres/postgres-xl/contrib/pgxc_ctl
make -j

su - postgres

systemctl stop ufw
systemctl disable ufw
systemctl status ufw

su - postgres
passwd postgres
su - postgres
ifconfig

