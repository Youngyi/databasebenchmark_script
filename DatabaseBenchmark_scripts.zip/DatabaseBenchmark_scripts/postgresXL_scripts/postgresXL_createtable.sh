CREATE TABLE LINES (
    LINEID varchar(22) NOT NULL,
    LINEDESC varchar(30) NOT NULL,
    LINECOLOR varchar(22)
) DISTRIBUTE BY REPLICATION;

CREATE TABLE STATIONS (
    STATIONID varchar(22) NOT NULL,
    STATIONDESC varchar(50) NOT NULL,
    MAINLINEID varchar(22)
) DISTRIBUTE BY REPLICATION;


CREATE TABLE SUBTYPE (
    SUBTYPEID varchar(22) NOT NULL,
    SUBTYPEDESC varchar(30) NOT NULL
) DISTRIBUTE BY REPLICATION;

CREATE TABLE KPI_landing (
    STATIONID varchar(22) NOT NULL,
    LINEID varchar(22) NOT NULL,
    DIRECTION varchar(22) NOT NULL,
    DTKPI varchar(22),
    KPI int
) DISTRIBUTE BY REPLICATION;

CREATE TABLE TRANSAC_landing (
    ID bigint  NOT NULL,
    STATIONIDIN varchar(22) NOT NULL,
    STATIONIDOUT varchar(22) NOT NULL,
    DTIN varchar(22),
    DTOUT varchar(22),
    OCTOPUS varchar(22) NOT NULL,
    SUBTYPE varchar(22) NOT NULL,
    TIME int
) DISTRIBUTE BY REPLICATION;


CREATE TABLE KPI (
    STATIONID varchar(3) NOT NULL,
    LINEID varchar(22) NOT NULL,
    DIRECTION varchar(2) NOT NULL,
    DTKPI timestamp,
    DTBUSINESS date,
    KPI int
) DISTRIBUTE BY REPLICATION;

CREATE TABLE TRANSAC (
    ID bigint  NOT NULL,
    STATIONIDIN varchar(22) NOT NULL,
    STATIONIDOUT varchar(22) NOT NULL,
    DTIN timestamp,
    DTBUSINESS date,
    DTOUT timestamp,
    OCTOPUS varchar(22) NOT NULL,
    SUBTYPE varchar(22) NOT NULL,
    TIME int
) DISTRIBUTE BY REPLICATION;


create table transac_y2017m01 ( check(dtbusiness>=DATE'2017-01-01' and dtbusiness<DATE'2017-02-01'))inherits(transac);
create table KPI_y2017m01 ( check(dtbusiness>=DATE'2017-01-01' and dtbusiness<DATE'2017-02-01'))inherits(kpi);

create table transac_y2017m02 ( check(dtbusiness>=DATE'2017-02-01' and dtbusiness<DATE'2017-03-01'))inherits(transac);
create table KPI_y2017m02 ( check(dtbusiness>=DATE'2017-02-01' and dtbusiness<DATE'2017-03-01'))inherits(kpi);

create table transac_y2017m03 ( check(dtbusiness>=DATE'2017-03-01' and dtbusiness<DATE'2017-04-01'))inherits(transac);
create table KPI_y2017m03 ( check(dtbusiness>=DATE'2017-03-01' and dtbusiness<DATE'2017-04-01'))inherits(kpi);

create table transac_y2017m04 ( check(dtbusiness>=DATE'2017-04-01' and dtbusiness<DATE'2017-05-01'))inherits(transac);
create table KPI_y2017m04 ( check(dtbusiness>=DATE'2017-04-01' and dtbusiness<DATE'2017-05-01'))inherits(kpi);

create table transac_y2017m05 ( check(dtbusiness>=DATE'2017-05-01' and dtbusiness<DATE'2017-06-01'))inherits(transac);
create table KPI_y2017m05 ( check(dtbusiness>=DATE'2017-05-01' and dtbusiness<DATE'2017-06-01'))inherits(kpi);

create table transac_y2017m06 ( check(dtbusiness>=DATE'2017-06-01' and dtbusiness<DATE'2017-07-01'))inherits(transac);
create table KPI_y2017m06 ( check(dtbusiness>=DATE'2017-06-01' and dtbusiness<DATE'2017-07-01'))inherits(kpi);

create table transac_y2017m07 ( check(dtbusiness>=DATE'2017-07-01' and dtbusiness<DATE'2017-08-01'))inherits(transac);
create table KPI_y2017m07 ( check(dtbusiness>=DATE'2017-07-01' and dtbusiness<DATE'2017-08-01'))inherits(kpi);

create table transac_y2017m08 ( check(dtbusiness>=DATE'2017-08-01' and dtbusiness<DATE'2017-09-01'))inherits(transac);
create table KPI_y2017m08 ( check(dtbusiness>=DATE'2017-08-01' and dtbusiness<DATE'2017-09-01'))inherits(kpi);

create table transac_y2017m09 ( check(dtbusiness>=DATE'2017-09-01' and dtbusiness<DATE'2017-10-01'))inherits(transac);
create table KPI_y2017m09 ( check(dtbusiness>=DATE'2017-09-01' and dtbusiness<DATE'2017-10-01'))inherits(kpi);

create table transac_y2017m10 ( check(dtbusiness>=DATE'2017-10-01' and dtbusiness<DATE'2017-11-01'))inherits(transac);
create table KPI_y2017m10 ( check(dtbusiness>=DATE'2017-10-01' and dtbusiness<DATE'2017-11-01'))inherits(kpi);

create table transac_y2017m11 ( check(dtbusiness>=DATE'2017-11-01' and dtbusiness<DATE'2017-12-01'))inherits(transac);
create table KPI_y2017m11 ( check(dtbusiness>=DATE'2017-11-01' and dtbusiness<DATE'2017-12-01'))inherits(kpi);

create table transac_y2017m12 ( check(dtbusiness>=DATE'2017-12-01' and dtbusiness<DATE'2018-01-01'))inherits(transac);
create table KPI_y2017m12 ( check(dtbusiness>=DATE'2017-12-01' and dtbusiness<DATE'2018-01-01'))inherits(kpi);

create table transac_y2018m02 ( check(dtbusiness>=DATE'2018-01-01' and dtbusiness<DATE'2018-02-01'))inherits(transac);
create table KPI_y2018m02 ( check(dtbusiness>=DATE'2018-01-01' and dtbusiness<DATE'2018-02-01'))inherits(kpi);

#--------------- creat indexs
CREATE INDEX transac_y2017m01_DTBUSINESS ON  transac_y2017m01 (DTBUSINESS);
CREATE INDEX transac_y2017m01_01 ON  transac_y2017m01 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m01_DTBUSINESS ON  KPI_y2017m01 (DTBUSINESS);

CREATE INDEX transac_y2017m02_DTBUSINESS ON  transac_y2017m02 (DTBUSINESS);
CREATE INDEX transac_y2017m02_01 ON  transac_y2017m02 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m02_DTBUSINESS ON  KPI_y2017m02 (DTBUSINESS);

CREATE INDEX transac_y2017m03_DTBUSINESS ON  transac_y2017m03 (DTBUSINESS);
CREATE INDEX transac_y2017m03_01 ON  transac_y2017m03 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m03_DTBUSINESS ON  KPI_y2017m03 (DTBUSINESS);

CREATE INDEX transac_y2017m04_DTBUSINESS ON  transac_y2017m04 (DTBUSINESS);
CREATE INDEX transac_y2017m04_01 ON  transac_y2017m04 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m04_DTBUSINESS ON  KPI_y2017m04 (DTBUSINESS);

CREATE INDEX transac_y2017m05_DTBUSINESS ON  transac_y2017m05 (DTBUSINESS);
CREATE INDEX transac_y2017m05_01 ON  transac_y2017m05 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m05_DTBUSINESS ON  KPI_y2017m05 (DTBUSINESS);

CREATE INDEX transac_y2017m06_DTBUSINESS ON  transac_y2017m06 (DTBUSINESS);
CREATE INDEX transac_y2017m06_01 ON  transac_y2017m06 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m06_DTBUSINESS ON  KPI_y2017m06 (DTBUSINESS);

CREATE INDEX transac_y2017m07_DTBUSINESS ON  transac_y2017m07 (DTBUSINESS);
CREATE INDEX transac_y2017m07_01 ON  transac_y2017m07 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m07_DTBUSINESS ON  KPI_y2017m07 (DTBUSINESS);

CREATE INDEX transac_y2017m08_DTBUSINESS ON  transac_y2017m08 (DTBUSINESS);
CREATE INDEX transac_y2017m08_01 ON  transac_y2017m08 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m08_DTBUSINESS ON  KPI_y2017m08 (DTBUSINESS);

CREATE INDEX transac_y2017m09_DTBUSINESS ON  transac_y2017m09 (DTBUSINESS);
CREATE INDEX transac_y2017m09_01 ON  transac_y2017m09 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m09_DTBUSINESS ON  KPI_y2017m09 (DTBUSINESS);

CREATE INDEX transac_y2017m10_DTBUSINESS ON  transac_y2017m10 (DTBUSINESS);
CREATE INDEX transac_y2017m10_01 ON  transac_y2017m10 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m10_DTBUSINESS ON  KPI_y2017m10 (DTBUSINESS);

CREATE INDEX transac_y2017m11_DTBUSINESS ON  transac_y2017m11 (DTBUSINESS);
CREATE INDEX transac_y2017m11_01 ON  transac_y2017m11 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m11_DTBUSINESS ON  KPI_y2017m11 (DTBUSINESS);

CREATE INDEX transac_y2017m12_DTBUSINESS ON  transac_y2017m12 (DTBUSINESS);
CREATE INDEX transac_y2017m12_01 ON  transac_y2017m12 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2017m12_DTBUSINESS ON  KPI_y2017m12 (DTBUSINESS);

CREATE INDEX transac_y2018m02_DTBUSINESS ON  transac_y2018m02 (DTBUSINESS);
CREATE INDEX transac_y2018m02_01 ON  transac_y2018m02 (STATIONIDIN, STATIONIDOUT, OCTOPUS);
CREATE INDEX KPI_y2018m02_DTBUSINESS ON  KPI_y2018m02 (DTBUSINESS);

#---------- create rule 
# CREATE RULE transac_insert_y2017m01 AS
# ON INSERT TO transac WHERE
#     (DTBUSINESS >= DATE '2017-01-01'  AND DTBUSINESS < DATE '2017-02-01' )
# DO INSTEAD
#     INSERT INTO transac_y2017m01 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m01 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-01-01'  AND DTBUSINESS < DATE '2017-02-01' )
DO INSTEAD
    INSERT INTO transac_y2017m01 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m02 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-02-01'  AND DTBUSINESS < DATE '2017-03-01' )
DO INSTEAD
    INSERT INTO transac_y2017m02 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m03 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-03-01'  AND DTBUSINESS < DATE '2017-04-01' )
DO INSTEAD
    INSERT INTO transac_y2017m03 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m04 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-04-01'  AND DTBUSINESS < DATE '2017-05-01' )
DO INSTEAD
    INSERT INTO transac_y2017m04 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m05 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-05-01'  AND DTBUSINESS < DATE '2017-06-01' )
DO INSTEAD
    INSERT INTO transac_y2017m05 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m06 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-06-01'  AND DTBUSINESS < DATE '2017-07-01' )
DO INSTEAD
    INSERT INTO transac_y2017m06 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m07 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-07-01'  AND DTBUSINESS < DATE '2017-08-01' )
DO INSTEAD
    INSERT INTO transac_y2017m07 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m08 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-08-01'  AND DTBUSINESS < DATE '2017-09-01' )
DO INSTEAD
    INSERT INTO transac_y2017m08 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m09 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-09-01'  AND DTBUSINESS < DATE '2017-10-01' )
DO INSTEAD
    INSERT INTO transac_y2017m09 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m10 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-10-01'  AND DTBUSINESS < DATE '2017-11-01' )
DO INSTEAD
    INSERT INTO transac_y2017m10 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m11 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-11-01'  AND DTBUSINESS < DATE '2017-12-01' )
DO INSTEAD
    INSERT INTO transac_y2017m11 VALUES (NEW.*);

CREATE RULE transac_insert_y2017m12 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2017-12-01'  AND DTBUSINESS < DATE '2018-01-01' )
DO INSTEAD
    INSERT INTO transac_y2017m12 VALUES (NEW.*);

CREATE RULE transac_insert_y2018m02 AS
ON INSERT TO transac WHERE
    (DTBUSINESS >= DATE '2018-01-01'  AND DTBUSINESS < DATE '2018-02-01' )
DO INSTEAD
    INSERT INTO transac_y2018m02 VALUES (NEW.*);



# CREATE OR REPLACE FUNCTION transac_insert_trigger()
# RETURNS TRIGGER AS $$
# BEGIN
#     IF ( NEW.DTBUSINESS >= DATE '2017-01-01'  AND
#          NEW.DTBUSINESS < DATE '2017-02-01' ) THEN
#         INSERT INTO transac_y2017m01 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-02-01' AND
#             NEW.DTBUSINESS < DATE '2017-03-01' ) THEN
#         INSERT INTO transac_y2017m02 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-03-01' AND
#             NEW.DTBUSINESS < DATE '2017-04-01' ) THEN
#         INSERT INTO transac_y2017m03 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-04-01' AND
#             NEW.DTBUSINESS < DATE '2017-05-01' ) THEN
#         INSERT INTO transac_y2017m04 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-05-01' AND
#             NEW.DTBUSINESS < DATE '2017-06-01' ) THEN
#         INSERT INTO transac_y2017m05 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-06-01' AND
#             NEW.DTBUSINESS < DATE '2017-07-01' ) THEN
#         INSERT INTO transac_y2017m06 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-07-01' AND
#             NEW.DTBUSINESS < DATE '2017-08-01' ) THEN
#         INSERT INTO transac_y2017m07 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-08-01' AND
#             NEW.DTBUSINESS < DATE '2017-09-01' ) THEN
#         INSERT INTO transac_y2017m08 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-09-01' AND
#             NEW.DTBUSINESS < DATE '2017-10-01' ) THEN
#         INSERT INTO transac_y2017m09 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-10-01' AND
#             NEW.DTBUSINESS < DATE '2017-11-01' ) THEN
#         INSERT INTO transac_y2017m10 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-11-01' AND
#             NEW.DTBUSINESS < DATE '2017-12-01' ) THEN
#         INSERT INTO transac_y2017m11 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-12-01' AND
#             NEW.DTBUSINESS < DATE '2018-01-01' ) THEN
#         INSERT INTO transac_y2017m12 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2018-01-01' AND
#             NEW.DTBUSINESS < DATE '2018-02-01' ) THEN
#         INSERT INTO transac_y2018m02 VALUES (NEW.*);
#     ELSE
#         RAISE EXCEPTION 'Date out of range.  Fix the measurement_insert_trigger() function!';
#     END IF;
#     RETURN NULL;
# END;
# $$
# LANGUAGE plpgsql;

CREATE RULE kpi_insert_y2017m01 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-01-01'  AND DTBUSINESS < DATE '2017-02-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m01 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m02 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-02-01'  AND DTBUSINESS < DATE '2017-03-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m02 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m03 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-03-01'  AND DTBUSINESS < DATE '2017-04-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m03 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m04 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-04-01'  AND DTBUSINESS < DATE '2017-05-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m04 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m05 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-05-01'  AND DTBUSINESS < DATE '2017-06-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m05 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m06 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-06-01'  AND DTBUSINESS < DATE '2017-07-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m06 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m07 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-07-01'  AND DTBUSINESS < DATE '2017-08-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m07 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m08 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-08-01'  AND DTBUSINESS < DATE '2017-09-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m08 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m09 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-09-01'  AND DTBUSINESS < DATE '2017-10-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m09 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m10 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-10-01'  AND DTBUSINESS < DATE '2017-11-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m10 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m11 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-11-01'  AND DTBUSINESS < DATE '2017-12-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m11 VALUES (NEW.*);

CREATE RULE kpi_insert_y2017m12 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2017-12-01'  AND DTBUSINESS < DATE '2018-01-01' )
DO INSTEAD
    INSERT INTO kpi_y2017m12 VALUES (NEW.*);

CREATE RULE kpi_insert_y2018m02 AS
ON INSERT TO kpi WHERE
    (DTBUSINESS >= DATE '2018-01-01'  AND DTBUSINESS < DATE '2018-02-01' )
DO INSTEAD
    INSERT INTO kpi_y2018m02 VALUES (NEW.*);

# CREATE OR REPLACE FUNCTION KPI_insert_trigger()
# RETURNS TRIGGER AS $$
# BEGIN
#     IF ( NEW.DTBUSINESS >= DATE '2017-01-01'  AND
#          NEW.DTBUSINESS < DATE '2017-02-01' ) THEN
#         INSERT INTO KPI_y2017m01 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-02-01' AND
#             NEW.DTBUSINESS < DATE '2017-03-01' ) THEN
#         INSERT INTO KPI_y2017m02 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-03-01' AND
#             NEW.DTBUSINESS < DATE '2017-04-01' ) THEN
#         INSERT INTO KPI_y2017m03 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-04-01' AND
#             NEW.DTBUSINESS < DATE '2017-05-01' ) THEN
#         INSERT INTO KPI_y2017m04 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-05-01' AND
#             NEW.DTBUSINESS < DATE '2017-06-01' ) THEN
#         INSERT INTO KPI_y2017m05 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-06-01' AND
#             NEW.DTBUSINESS < DATE '2017-07-01' ) THEN
#         INSERT INTO KPI_y2017m06 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-07-01' AND
#             NEW.DTBUSINESS < DATE '2017-08-01' ) THEN
#         INSERT INTO KPI_y2017m07 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-08-01' AND
#             NEW.DTBUSINESS < DATE '2017-09-01' ) THEN
#         INSERT INTO KPI_y2017m08 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-09-01' AND
#             NEW.DTBUSINESS < DATE '2017-10-01' ) THEN
#         INSERT INTO KPI_y2017m09 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-10-01' AND
#             NEW.DTBUSINESS < DATE '2017-11-01' ) THEN
#         INSERT INTO KPI_y2017m10 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-11-01' AND
#             NEW.DTBUSINESS < DATE '2017-12-01' ) THEN
#         INSERT INTO KPI_y2017m11 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2017-12-01' AND
#             NEW.DTBUSINESS < DATE '2018-01-01' ) THEN
#         INSERT INTO KPI_y2017m12 VALUES (NEW.*);
#     ELSIF ( NEW.DTBUSINESS >= DATE '2018-01-01' AND
#             NEW.DTBUSINESS < DATE '2018-02-01' ) THEN
#         INSERT INTO KPI_y2018m02 VALUES (NEW.*);
#     ELSE
#         RAISE EXCEPTION 'Date out of range.  Fix the measurement_insert_trigger() function!';
#     END IF;
#     RETURN NULL;
# END;
# $$
# LANGUAGE plpgsql;

# CREATE TRIGGER KPI_insert_trigger
#     BEFORE INSERT ON kpi
#     FOR EACH ROW EXECUTE PROCEDURE KPI_insert_trigger();

# CREATE TRIGGER transac_insert_trigger
#     BEFORE INSERT ON transac
#     FOR EACH ROW EXECUTE PROCEDURE transac_insert_trigger();

##echo 'postgres_partition_index_triggles  ----- start -----'>> postgres_partition_index_triggles.log

# 很重要， 将 landing 转到 final
INSERT INTO KPI select STATIONID, LINEID, DIRECTION,to_timestamp(substring(DTKPI,1,19),'YYYY-MM-DD HH24:MI:SS') as DTKPI,to_Date(substring(dtkpi from 1 for 10), 'YYYY-MM-DD') as DTBUSINESS, KPI from KPI_landing;
INSERT INTO TRANSAC select ID, STATIONIDIN, STATIONIDOUT, to_timestamp(substring(dtin,1,19),'YYYY-MM-DD HH24:MI:SS') as dtin, to_Date(substring(DTIN from 1 for 10), 'YYYY-MM-DD') as DTBUSINESS, to_timestamp(substring(dtout,1,19),'YYYY-MM-DD HH24:MI:SS') as dtout,OCTOPUS,SUBTYPE,TIME from TRANSAC_landing;

## echo 'postgres_partition_index_triggles  ----- start -----'>> postgres_partition_index_triggles.log

DROP table transac CASCADE;
drop table transac;
drop table transac_y2017m01;
drop table transac_y2017m02;
drop table transac_y2017m03;
drop table transac_y2017m04;
drop table transac_y2017m05;
drop table transac_y2017m06;
drop table transac_y2017m07;
drop table transac_y2017m08;
drop table transac_y2017m09;
drop table transac_y2017m10;
drop table transac_y2017m11;
drop table transac_y2017m12;
drop table transac_y2018m02;

DROP table kpi CASCADE;
drop table KPI;
drop table KPI_y2017m01;
drop table KPI_y2017m02;
drop table KPI_y2017m03;
drop table KPI_y2017m04;
drop table KPI_y2017m05;
drop table KPI_y2017m06;
drop table KPI_y2017m07;
drop table KPI_y2017m08;
drop table KPI_y2017m09;
drop table KPI_y2017m10;
drop table KPI_y2017m11;
drop table KPI_y2017m12;
drop table KPI_y2018m02;


drop table KPI_landing;
drop table TRANSAC_landing;
drop table LINES;
drop table STATIONS;
drop table SUBTYPE;
