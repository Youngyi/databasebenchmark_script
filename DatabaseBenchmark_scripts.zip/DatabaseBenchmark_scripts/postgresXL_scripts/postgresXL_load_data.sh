for x in $(ls /home/yyangcp/IndepentProjectData/Data/TableReference/postgres_lines/);
do psql -h 127.0.0.1 -p 5432 -U postgres yyangcp -c "\copy lines FROM '/home/yyangcp/IndepentProjectData/Data/TableReference/postgres_lines/$x' DELIMITER ',' CSV"; done
for x in $(ls /home/yyangcp/IndepentProjectData/Data/TableReference/postgres_stations/);
do psql -h 127.0.0.1 -p 5432 -U postgres yyangcp -c "\copy STATIONS FROM '/home/yyangcp/IndepentProjectData/Data/TableReference/postgres_stations/$x' DELIMITER ',' CSV"; done
for x in $(ls /home/yyangcp/IndepentProjectData/Data/TableReference/postgres_subtype/);
do psql -h 127.0.0.1 -p 5432 -U postgres yyangcp -c "\copy SUBTYPE FROM '/home/yyangcp/IndepentProjectData/Data/TableReference/postgres_subtype/$x' DELIMITER ',' CSV"; done

## landing table 里 DTIN 的变量类型是不一样的
# 将 KPI 数据导入server postgres 数据库中，这里注意 IP 地址和文件打开路径
for x in $(ls /home/yyangcp/IndepentProjectData/Data/TableKpi/postgres_kpi/);
do psql -h 127.0.0.1 -p 5432 -U postgres yyangcp -c "\copy KPI_landing FROM '/home/yyangcp/IndepentProjectData/Data/TableKpi/postgres_kpi/$x' DELIMITER ',' CSV"; done

# 将 TRANSAC 数据导入server postgres 数据库中，这里注意 IP 地址和文件打开路径
for x in $(ls /home/yyangcp/IndepentProjectData/Data/TableTransac/);
do psql -h 127.0.0.1 -U postgres -d yyangcp -c "\copy TRANSAC_landing FROM '/home/yyangcp/IndepentProjectData/Data/TableTransac/$x' DELIMITER ',' CSV"; done


## INSERT INTO KPI select STATIONID, LINEID, DIRECTION, DTKPI,to_Date(substring(dtkpi from 1 for 10), 'YYYY-MM-DD') as DTBUSINESS, KPI from KPI_landing;
# do psql -h 127.0.0.1 -U postgres -d yyangcp -c "INSERT INTO KPI select STATIONID, LINEID, DIRECTION, DTKPI,to_Date(substring(dtkpi from 1 for 10), 'YYYY-MM-DD') as DTBUSINESS, KPI from KPI_landing"; done
## INSERT INTO TRANSAC select ID, STATIONIDIN, STATIONIDOUT, DTIN, to_Date(substring(dtin from 1 for 10), 'YYYY-MM-DD') as DTBUSINESS,DTOUT,OCTOPUS,SUBTYPE,TIME from TRANSAC_landing;
# do psql -h 127.0.0.1 -U postgres -d yyangcp -c "INSERT INTO TRANSAC select ID, STATIONIDIN, STATIONIDOUT, DTIN, to_Date(substring(dtin from 1 for 10), 'YYYY-MM-DD') as DTBUSINESS,DTOUT,OCTOPUS,SUBTYPE,TIME from TRANSAC_landing"; done