psql -h 127.0.0.1 -U postgres -d test -w -c "CREATE TABLE TRANSAC_landing (
    ID bigint  NOT NULL,
    STATIONIDIN char (3) NOT NULL,
    STATIONIDOUT char (3) NOT NULL,
    DTIN varchar,
    DTOUT timestamp,
    OCTOPUS char (1) NOT NULL,
    SUBTYPE char (4) NOT NULL,
    TIME int
);"
psql -h 127.0.0.1 -U postgres -d test -w -c "CREATE TABLE TRANSAC (
    ID bigint  NOT NULL,
    STATIONIDIN char (3) NOT NULL,
    STATIONIDOUT char (3) NOT NULL,
    DTIN varchar,
    DTBUSINESS date,
    DTOUT timestamp,
    OCTOPUS char (1) NOT NULL,
    SUBTYPE char (4) NOT NULL,
    TIME int
);"

psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201701_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201702_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201703_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201704_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201705_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201706_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201707_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201708_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201709_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201710_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201711_backup.csv' DELIMITER ',' CSV"
psql -h 127.0.0.1 -U postgres -d test -w -c "\copy TRANSAC_landing FROM '/IndepentProjectData/Data/TableTransac/datatransac_201712_backup.csv' DELIMITER ',' CSV"

psql -h 127.0.0.1 -U postgres -d test -w -c "INSERT INTO TRANSAC select ID, STATIONIDIN, STATIONIDOUT, DTIN, to_Date(substring(dtin from 1 for 10), 'YYYY-MM-DD') as DTBUSINESS,DTOUT,OCTOPUS,SUBTYPE,TIME from TRANSAC_landing;"
