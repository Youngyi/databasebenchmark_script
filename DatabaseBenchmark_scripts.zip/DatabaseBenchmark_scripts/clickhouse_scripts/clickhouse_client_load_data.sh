# connect with server:
##clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test
# connect with server:
##clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test

date >> /IndepentProjectData/running_log/clickhouse_client_load.log
#cat /IndepentProjectData/Data/TableReference/postgres_lines/transac_Lines_backup.csv | time -ao -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="INSERT INTO test.lines FORMAT CSV"

cat /IndepentProjectData/Data/TableReference/postgres_lines/transac_Lines_backup.csv |  time  -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test  --query="INSERT INTO test.lines FORMAT CSV"
cat /IndepentProjectData/Data/TableReference/postgres_stations/transac_Stations_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.stations FORMAT CSV"
cat /IndepentProjectData/Data/TableReference/postgres_subtype/transac_SubType_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.subtype FORMAT CSV"

cat /IndepentProjectData/Data/TableKpi/postgres_kpi/dataKPI_2017_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.kpi FORMAT CSV"
cat /IndepentProjectData/Data/TableKpi/postgres_kpi/dataKPI_2018_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.kpi FORMAT CSV"

cat /IndepentProjectData/Data/TableTransac/datatransac_201701_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201702_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201703_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201704_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201705_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201706_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201707_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201708_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201709_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201710_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201711_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201712_backup.csv | time -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.transac FORMAT CSV"

date >>/IndepentProjectData/running_log/clickhouse_client_load.log
