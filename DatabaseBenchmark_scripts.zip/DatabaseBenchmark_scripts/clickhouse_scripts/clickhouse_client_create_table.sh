# connect with server:
##clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test

echo 'CREATE  DATABASE  IF  NOT  EXISTS  test' | POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE test.kpi (STATIONID String, LINED String, DIRECTION String, DTKPI DateTime, KPI Int64) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE test.transac ( ID Int32, STATIONIDIN String, STATIONIDOUT String,TIN DateTime,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE test.stations (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE test.lines (LINED String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE test.subtype (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'




