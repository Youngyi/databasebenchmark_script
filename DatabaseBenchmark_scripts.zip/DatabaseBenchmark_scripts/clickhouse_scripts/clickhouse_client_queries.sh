echo 'Clickhouse-client test queries START--------------------'>> clickhouse_client_queries.log 
date >> clickhouse_client_queries.log


echo '# 1- Count ID'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select count(ID) as CNT from test.transac;">> clickhouse_client_queries.log 

echo '# 2- Count distinct ID'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query='Select count(distinct ID) as CNTD from test.transac;'>> clickhouse_client_queries.log

echo '# 3-Count distinct ID and Count ID and AVG time'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select count(ID) as CNT,count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from test.transac;">> clickhouse_client_queries.log

echo '# 4- with Group by 1 field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN, count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from test.transac GROUP BY STATIONIDIN;">> clickhouse_client_queries.log

echo '# 5- (3 indic) with Group by 3 field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN, STATIONIDOUT, OCTOPUS, count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from test.transac GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS;">> clickhouse_client_queries.log


echo '# 6- (3 indic) with Group by multiple fields and joins 3 tables'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select li.LINEDESC as LINEIN,lo.LINEDESC as LINEOUT, t.OCTOPUS as OCTOPUS, st.SUBTYPEDESC as SUBTYPEDESC, count(t.ID) as CNT,count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME from test.transac t left join test.stations si on (t.STATIONIDIN = si.STATIONID) left join test.stations so on (t.STATIONIDOUT = so.STATIONID) left join LINES li on (si.MAINLINEID = li.LINEID) left join test.lines lo on (so.MAINLINEID = lo.LINEID) outer join test.subtype st on (t.SUBTYPE = st.SUBTYPEID) GROUP BY li.LINEDESC, lo.LINEDESC, t.OCTOPUS, st.SUBTYPEDESC;"


echo '# 7- (3 indic) with Group by 1 datetime binning formula'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select to_timestamp(floor( EXTRACT(EPOCH FROM DTIN) / 900 ) * 900) as DTIN15MIN, count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from test.transac GROUP BY to_timestamp(floor( EXTRACT(EPOCH FROM DTIN) / 900 ) * 900);"


echo '# 8- (3 indic) + AVG KPI with Group by multiple fields and joins 2 tables plus KPI table'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select k.DTKPI,k.STATIONID,k.LINEID,k.DIRECTION,t.OCTOPUS, count(t.ID) as CNT, count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME, SUM(k.KPI) as SUMKPI from test.transac t left join test.stations si on (t.STATIONIDIN = si.STATIONID) left join test.lines li on (si.MAINLINEID = li.LINEID) left join test.kpi k on (to_timestamp(floor( EXTRACT(EPOCH FROM t.DTIN) / 900 ) * 900) = k.DTKPI and t.STATIONIDIN = k.STATIONID and li.LINEID=k.LINEID) GROUP BY k.DTKPI, k.STATIONID, k.LINEID, k.DIRECTION, t.OCTOPUS;"


echo '# 9- (3 indic) with filter on the partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from test.transac where DTBUSINESS >= toDate('20171101', 'YYYMMDD');"

echo '# 10- (3 indic) with Group by 1 field with filter on the partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from test.transac where DTBUSINESS >= toDate('20171101', 'YYYMMDD') GROUP BY STATIONIDIN;"


echo '# 11- (3 indic) with Group by 3 field with filter on the partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from test.transac where DTBUSINESS >= toDate('20171101', 'YYYMMDD') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS;"


echo '# 12- (3 indic) with Group by multiple fields and joins 3 tables with filter on the partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select li.LINEDESC as LINEIN, lo.LINEDESC as LINEOUT, t.OCTOPUS as OCTOPUS, st.SUBTYPEDESC as SUBTYPEDESC, count(t.ID) as CNT,count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME from test.transac t left join test.stations si on (t.STATIONIDIN = si.STATIONID)
left join test.stations so on (t.STATIONIDOUT = so.STATIONID) left join LINES li on (si.MAINLINEID = li.LINEID)
left join test.lines lo on (so.MAINLINEID = lo.LINEID)
outer join test.subtype st on (t.SUBTYPE = st.SUBTYPEIDID)
where t.DTBUSINESS >= toDate('20171101', 'YYYMMDD') GROUP BY
li.LINEDESC, lo.LINEDESC, t.OCTOPUS, st.SUBTYPEDESC;"


echo '# 13- (3 indic) with Group by 1 datetime binning formula with filter on the partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select to_timestamp(floor( EXTRACT(EPOCH FROM DTIN) / 900 ) * 900) as DTIN15MIN, count(ID) as CNT,count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from test.transac
where DTBUSINESS >= toDate('20171101', 'YYYMMDD') GROUP BY
to_timestamp(floor( EXTRACT(EPOCH FROM DTIN) / 900 ) * 900);"


echo '# 14- (3 indic) + AVG KPI with Group by multiple fields and joins 2 tables plus KPI table with filter on the partition field of transaction table'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select
k.DTKPI,
k.STATIONID,
k.LINEID,
k.DIRECTION,
t.OCTOPUS,
count(t.ID) as CNT, count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME, SUM(k.KPI) as SUMKPI
from test.transac t
left join test.stations si on (t.STATIONIDIN = si.STATIONID)
left join test.lines li on (si.MAINLINEID = li.LINEID)
left join test.kpi k on (to_timestamp(floor( EXTRACT(EPOCH FROM t.DTIN) / 900 ) * 900)
= k.DTKPI and t.STATIONIDIN = k.STATIONID and li.LINEID=k.LINEID) where t.DTBUSINESS >= toDate('20171101', 'YYYMMDD')
GROUP BY
k.DTKPI, k.STATIONID, k.LINEID, k.DIRECTION, t.OCTOPUS;"

#ok
echo '# 15- (3 indic) with filter on non-partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select
count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME from test.transac
where SUBTYPE in ('AVUP', 'PNQI');"


echo '# 16- (3 indic) with Group by 1 field with filter on non-partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select
STATIONIDIN,
count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME
from test.transac
where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN;"


echo '# 17- (3 indic) with Group by 3 field with filter on non-partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select
STATIONIDIN,
STATIONIDOUT, OCTOPUS,
count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME
from test.transac
where SUBTYPE in ('AVUP', 'PNQI') GROUP BY
STATIONIDIN, STATIONIDOUT, OCTOPUS;"

echo '# 18- (3 indic) with Group by multiple fields and joins 3 tables with filter on non-partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select
li.LINEDESC as LINEIN,
lo.LINEDESC as LINEOUT, t.OCTOPUS as OCTOPUS, st.SUBTYPEDESC as SUBTYPEDESC, count(t.ID) as CNT,
count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME
from test.transac t
left join test.stations si on (t.STATIONIDIN = si.STATIONID)
left join test.stations so on (t.STATIONIDOUT = so.STATIONID) left join LINES li on (si.MAINLINEID = li.LINEID)
left join test.lines lo on (so.MAINLINEID = lo.LINEID)
outer join test.subtype st on (t.SUBTYPE = st.SUBTYPEIDID)
where t.SUBTYPE in ('AVUP', 'PNQI') GROUP BY
li.LINEDESC, lo.LINEDESC, t.OCTOPUS, st.SUBTYPEDESC;"


echo '# 19-  (3 indic) with Group by 1 datetime binning formula with filter on non-partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select
to_timestamp(floor( EXTRACT(EPOCH FROM DTIN) / 900 ) * 900) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from test.transac
where SUBTYPE in ('AVUP', 'PNQI') GROUP BY
to_timestamp(floor( EXTRACT(EPOCH FROM DTIN) / 900 ) * 900);"


echo '# 20- (3 indic) + AVG KPI with Group by multiple fields and joins 2 tables plus KPI table with filter on non-partition field'>> clickhouse_client_queries.log
time -ao clickhouse_client_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select k.DTKPI,k.STATIONID,k.LINEID,k.DIRECTION,t.OCTOPUS,count(t.ID) as CNT, count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME, SUM(k.KPI) as SUMKPI from test.transac t left join test.stations si on (t.STATIONIDIN = si.STATIONID) left join test.lines li on (si.MAINLINEID = li.LINEID) left join test.kpi k on (to_timestamp(floor( EXTRACT(EPOCH FROM t.DTIN) / 900 ) * 900) = k.DTKPI and t.STATIONIDIN = k.STATIONID and li.LINEID=k.LINEID) where t.SUBTYPE in ('AVUP', 'PNQI') GROUP BY k.DTKPI, k.STATIONID, k.LINEID, k.DIRECTION, t.OCTOPUS;"

echo 'Clickhouse-client test queries STOP--------------------'>> clickhouse_client_queries.log 
date >> clickhouse_client_queries.log

