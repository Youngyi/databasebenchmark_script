
echo '# 7- (3 indic) with Group by 1 datetime binning formula'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log  clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select toStartOfFifteenMinutes(DTIN) as DTIN15MIN,count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from TRANSAC GROUP BY DTIN15MIN  SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log  clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select toStartOfFifteenMinutes(DTIN) as DTIN15MIN,count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from TRANSAC GROUP BY DTIN15MIN  SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log  clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select toStartOfFifteenMinutes(DTIN) as DTIN15MIN,count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from TRANSAC GROUP BY DTIN15MIN  SETTINGS max_bytes_before_external_group_by = 5000000000;"


echo '# 8- (3 indic) + AVG KPI with Group by multiple fields and joins 2 tables plus KPI table'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log  clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
( SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, DTIN AS TIMEIN,count(ID) as CNT, count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
FROM TRANSAC GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN ) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM STATIONS) ANY LEFT JOIN
(SELECT LINEID FROM LINES)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log  clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
( SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, DTIN AS TIMEIN,count(ID) as CNT, count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
FROM TRANSAC GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN ) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM STATIONS) ANY LEFT JOIN
(SELECT LINEID FROM LINES)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log  clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
( SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, DTIN AS TIMEIN,count(ID) as CNT, count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
FROM TRANSAC GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN ) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION 
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM STATIONS) ANY LEFT JOIN
(SELECT LINEID FROM LINES)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# 9- (3 indic) with filter on the partition field'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from  TRANSAC where DTBUSINESS >= toDate('2018-01-01');"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from  TRANSAC where DTBUSINESS >= toDate('2018-01-01');"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from  TRANSAC where DTBUSINESS >= toDate('2018-01-01');"


echo '# 10- (3 indic) with Group by 1 field with filter on the partition field'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  TRANSAC where DTIN >= toDate('2018-01-01') GROUP BY STATIONIDIN SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  TRANSAC where DTIN >= toDate('2018-01-01') GROUP BY STATIONIDIN SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  TRANSAC where DTIN >= toDate('2018-01-01') GROUP BY STATIONIDIN SETTINGS max_bytes_before_external_group_by = 5000000000;"


echo '# 11- (3 indic) with Group by 3 field with filter on the partition field'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  TRANSAC where DTBUSINESS >= toDate('2018-01-01') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  TRANSAC where DTBUSINESS >= toDate('2018-01-01') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from  TRANSAC where DTBUSINESS >= toDate('2018-01-01') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"

echo '# 12- (3 indic) with Group by multiple fields and joins 3 tables with filter on the partition field'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="SELECT LINEINDESC,LINEOUTDESC, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEINDESC, LINEIDOUT,OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,LINEIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,STATIONIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM ( SELECT OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME,STATIONIDIN,STATIONIDOUT FROM (SELECT t.STATIONIDIN AS STATIONIDIN, t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS, t.SUBTYPE AS SUBTYPEID, count(t.ID) as CNT, count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME FROM TRANSAC t WHERE t.DTBUSINESS >= toDate('2017-11-01') GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE )ANY LEFT JOIN ( SELECT SUBTYPEID, SUBTYPEDESC FROM SUBTYPE)USING (SUBTYPEID))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM STATIONS )USING(STATIONIDIN))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM STATIONS )USING(STATIONIDOUT))ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM LINES )USING(LINEIDIN))ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM LINES )USING(LINEIDOUT);"
echo '# with cache 2th'>> test_queries.log
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="SELECT LINEINDESC,LINEOUTDESC, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEINDESC, LINEIDOUT,OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,LINEIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,STATIONIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM ( SELECT OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME,STATIONIDIN,STATIONIDOUT FROM (SELECT t.STATIONIDIN AS STATIONIDIN, t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS, t.SUBTYPE AS SUBTYPEID, count(t.ID) as CNT, count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME FROM TRANSAC t WHERE t.DTBUSINESS >= toDate('2017-11-01') GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE )ANY LEFT JOIN ( SELECT SUBTYPEID, SUBTYPEDESC FROM SUBTYPE)USING (SUBTYPEID))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM STATIONS )USING(STATIONIDIN))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM STATIONS )USING(STATIONIDOUT))ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM LINES )USING(LINEIDIN))ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM LINES )USING(LINEIDOUT);" 
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="SELECT LINEINDESC,LINEOUTDESC, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEINDESC, LINEIDOUT,OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,LINEIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM (SELECT LINEIDIN,STATIONIDOUT, OCTOPUS,SUBTYPEDESC, CNT,CNTD, AVGTIME FROM ( SELECT OCTOPUS, SUBTYPEDESC, CNT,CNTD, AVGTIME,STATIONIDIN,STATIONIDOUT FROM (SELECT t.STATIONIDIN AS STATIONIDIN, t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS, t.SUBTYPE AS SUBTYPEID, count(t.ID) as CNT, count(distinct t.ID) as CNTD, AVG(t.TIME) as AVGTIME FROM TRANSAC t WHERE t.DTBUSINESS >= toDate('2017-11-01') GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE )ANY LEFT JOIN ( SELECT SUBTYPEID, SUBTYPEDESC FROM SUBTYPE)USING (SUBTYPEID))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM STATIONS )USING(STATIONIDIN))ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM STATIONS )USING(STATIONIDOUT))ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM LINES )USING(LINEIDIN))ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM LINES )USING(LINEIDOUT);" 

echo '# 13- (3 indic) with Group by 1 datetime binning formula with filter on the partition field'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
Select
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from TRANSAC
where DTBUSINESS >= toDate('2017-11-01') GROUP BY
toStartOfFifteenMinutes(DTIN);"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
Select
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from TRANSAC
where DTBUSINESS >= toDate('2017-11-01') GROUP BY
toStartOfFifteenMinutes(DTIN);"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
Select
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from TRANSAC
where DTBUSINESS >= toDate('2017-11-01') GROUP BY
toStartOfFifteenMinutes(DTIN);"

echo '# 14- (3 indic) + AVG KPI with Group by multiple fields and joins 2 tables plus KPI table with filter on the partition field of transaction table'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM 
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI 
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME 
FROM TRANSAC
WHERE DTBUSINESS >= toDate('2017-11-01')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as
SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION 
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM STATIONS) ANY LEFT JOIN
(SELECT LINEID FROM LINES)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM 
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI 
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME 
FROM TRANSAC
WHERE DTBUSINESS >= toDate('2017-11-01')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as
SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM STATIONS) ANY LEFT JOIN
(SELECT LINEID FROM LINES)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM 
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI 
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME 
FROM TRANSAC
WHERE DTBUSINESS >= toDate('2017-11-01')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as
SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM STATIONS) ANY LEFT JOIN
(SELECT LINEID FROM LINES)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# 15- (3 indic) with filter on non-partition field'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from TRANSAC where SUBTYPE in ('AVUP', 'PNQI');"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from TRANSAC where SUBTYPE in ('AVUP', 'PNQI');"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select count(ID) as CNT,count(distinct ID) as CNTD,AVG(TIME) as AVGTIME from TRANSAC where SUBTYPE in ('AVUP', 'PNQI');"


echo '# 16- (3 indic) with Group by 1 field with filter on non-partition field'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from TRANSAC where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from TRANSAC where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from TRANSAC where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN SETTINGS  max_bytes_before_external_group_by = 5000000000;"

echo '# 17- (3 indic) with Group by 3 field with filter on non-partition field'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from TRANSAC where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from TRANSAC where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from TRANSAC where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="Select STATIONIDIN,STATIONIDOUT, OCTOPUS,count(ID) as CNT, count(distinct ID) as CNTD, AVG(TIME) as AVGTIME from TRANSAC where SUBTYPE in ('AVUP', 'PNQI') GROUP BY STATIONIDIN, STATIONIDOUT, OCTOPUS SETTINGS  max_bytes_before_external_group_by = 5000000000;"

echo '# 18- (3 indic) with Group by multiple fields and joins 3 tables with filter on non-partition field'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="SELECT LINEINDESC,LINEOUTDESC,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME 
FROM(SELECT LINEINDESC,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,STATIONIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME,STATIONIDIN,STATIONIDOUT
FROM(SELECT t.STATIONIDIN AS STATIONIDIN,t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS,t.SUBTYPE AS SUBTYPEID,count(t.ID) as CNT,count(distinct t.ID) as CNTD,AVG(t.TIME) as AVGTIME
FROM TRANSAC t where t.SUBTYPE in ('AVUP', 'PNQI') 
GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE 
)ANY LEFT JOIN (SELECT SUBTYPEID, SUBTYPEDESC FROM test.SUBTYPE)USING (SUBTYPEID)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM test.STATIONS)USING(STATIONIDIN)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM test.STATIONS)USING(STATIONIDOUT)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM test.LINES)USING(LINEIDIN)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM test.LINES)USING(LINEIDOUT) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="SELECT LINEINDESC,LINEOUTDESC,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME 
FROM(SELECT LINEINDESC,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,STATIONIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME,STATIONIDIN,STATIONIDOUT
FROM(SELECT t.STATIONIDIN AS STATIONIDIN,t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS,t.SUBTYPE AS SUBTYPEID,count(t.ID) as CNT,count(distinct t.ID) as CNTD,AVG(t.TIME) as AVGTIME
FROM TRANSAC t where t.SUBTYPE in ('AVUP', 'PNQI') 
GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE 
)ANY LEFT JOIN (SELECT SUBTYPEID, SUBTYPEDESC FROM test.SUBTYPE)USING (SUBTYPEID)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM test.STATIONS)USING(STATIONIDIN)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM test.STATIONS)USING(STATIONIDOUT)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM test.LINES)USING(LINEIDIN)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM test.LINES)USING(LINEIDOUT) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="SELECT LINEINDESC,LINEOUTDESC,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME 
FROM(SELECT LINEINDESC,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,LINEIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT LINEIDIN,STATIONIDOUT,OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME
FROM(SELECT OCTOPUS,SUBTYPEDESC,CNT,CNTD,AVGTIME,STATIONIDIN,STATIONIDOUT
FROM(SELECT t.STATIONIDIN AS STATIONIDIN,t.STATIONIDOUT AS STATIONIDOUT,t.OCTOPUS OCTOPUS,t.SUBTYPE AS SUBTYPEID,count(t.ID) as CNT,count(distinct t.ID) as CNTD,AVG(t.TIME) as AVGTIME
FROM TRANSAC t where t.SUBTYPE in ('AVUP', 'PNQI') 
GROUP BY t.STATIONIDIN, t.STATIONIDOUT, t.OCTOPUS, t.SUBTYPE 
)ANY LEFT JOIN (SELECT SUBTYPEID, SUBTYPEDESC FROM test.SUBTYPE)USING (SUBTYPEID)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDIN, MAINLINEID LINEIDIN FROM test.STATIONS)USING(STATIONIDIN)
)ANY LEFT JOIN (SELECT STATIONID AS STATIONIDOUT, MAINLINEID LINEIDOUT FROM test.STATIONS)USING(STATIONIDOUT)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDIN, LINEDESC AS LINEINDESC FROM test.LINES)USING(LINEIDIN)
)ANY LEFT JOIN (SELECT LINEID AS LINEIDOUT, LINEDESC AS LINEOUTDESC FROM test.LINES)USING(LINEIDOUT) SETTINGS max_bytes_before_external_group_by = 5000000000;"


echo '# 19-  (3 indic) with Group by 1 datetime binning formula with filter on non-partition field'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from TRANSAC
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY toStartOfFifteenMinutes(DTIN) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from TRANSAC
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY toStartOfFifteenMinutes(DTIN) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT
toStartOfFifteenMinutes(DTIN) as DTIN15MIN, count(ID) as CNT,
count(distinct ID) as CNTD,
AVG(TIME) as AVGTIME
from TRANSAC
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY toStartOfFifteenMinutes(DTIN) SETTINGS max_bytes_before_external_group_by = 5000000000;"

echo '# 20- (3 indic) + AVG KPI with Group by multiple fields and joins 2 tables plus KPI table with filter on non-partition field'>> test_queries.log 
echo '# without cache'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD, AVG(TIME) as AVGTIME 
FROM TRANSAC
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN 
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION 
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM STATIONS) ANY LEFT JOIN
(SELECT LINEID FROM LINES)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 2th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD, AVG(TIME) as AVGTIME 
FROM TRANSAC
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN 
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION 
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM STATIONS) ANY LEFT JOIN
(SELECT LINEID FROM LINES)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"
echo '# with cache 3th'>> test_queries.log 
time -ao test_queries.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="
SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT TIMEIN,STATIONID, LINEID, DIRECTION, OCTOPUS, CNT, CNTD, AVGTIME, SUMKPI
FROM
(SELECT OCTOPUS, STATIONIDIN AS STATIONID, toStartOfFifteenMinutes(DTIN) AS TIMEIN, count(ID) as CNT,count(distinct ID) as CNTD, AVG(TIME) as AVGTIME 
FROM TRANSAC
where SUBTYPE in ('AVUP', 'PNQI')
GROUP BY OCTOPUS, STATIONIDIN AS STATIONID, DTIN 
) ANY LEFT JOIN
(SELECT DTKPI AS TIMEIN, STATIONID, LINEID, DIRECTION, SUM(KPI) as SUMKPI
FROM KPI
GROUP BY DTKPI, STATIONID, LINEID, DIRECTION
)USING(STATIONID, TIMEIN ) )ANY LEFT JOIN
(SELECT STATIONID, LINEID
FROM
(SELECT STATIONID, MAINLINEID AS LINEID FROM STATIONS) ANY LEFT JOIN
(SELECT LINEID FROM LINES)
USING(LINEID)
)USING(STATIONID, LINEID) SETTINGS max_bytes_before_external_group_by = 5000000000;"


echo 'Clickhouse-client test queries STOP--------------------'>> test_queries.log 
date >> test_queries.log 


