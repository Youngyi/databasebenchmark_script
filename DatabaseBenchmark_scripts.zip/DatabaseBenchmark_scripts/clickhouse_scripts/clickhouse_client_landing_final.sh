echo 'Clickhouse-client test for transaction and kpi START--------------------'>> clickhouse_client_landing_final.log 
date >> clickhouse_client_landing_final.log

#create testLF database
echo 'CREATE  DATABASE  IF  NOT  EXISTS  testLF' | POST 'http://52.231.186.18:8123/'

#create table landing and final in testLF
echo 'CREATE TABLE IF  NOT  EXISTS testLF.landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,TIN DateTime,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'
echo 'CREATE TABLE IF  NOT  EXISTS testLF.final ( ID Int32, STATIONIDIN String, STATIONIDOUT String,TIN DateTime,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'
#load dataset 
echo 'load ------------ 1th ------------ dataset in landing table'>> clickhouse_client_landing_final.log 
cat /IndepentProjectData/Data/TableTransac/datatransac_201701_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"

#transfer the landing data to final table
echo 'transfer the landing data 1th to final table'>> clickhouse_client_landing_final.log
time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.final
select ID,
STATIONIDIN,
STATIONIDOUT,
TIN,
DTOUT,
OCTOPUS,
SUBTYPE,
TIME
from testLF.landing"

#truncate or drop-create landing table
echo 'drop-create 1 landing table'>> clickhouse_client_landing_final.log
time -ao clickhouse_client_landing_final.log echo 'drop TABLE testLF.landing '| POST 'http://52.231.186.18:8123/'
time -ao clickhouse_client_landing_final.log echo 'CREATE TABLE testLF.landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,TIN DateTime,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'


#load dataset
echo 'load ------------ 2th ------------ dataset in landing table'>> clickhouse_client_landing_final.log 
cat /IndepentProjectData/Data/TableTransac/datatransac_201702_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"

#transfer the landing data to final table
echo 'transfer the landing data 2th to final table'>> clickhouse_client_landing_final.log
time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.final
select ID,
STATIONIDIN,
STATIONIDOUT,
TIN,
DTOUT,
OCTOPUS,
SUBTYPE,
TIME
from testLF.landing"

#truncate or drop-create landing table
echo 'drop-create 2 landing table'>> clickhouse_client_landing_final.log
echo 'drop TABLE testLF.landing '| POST 'http://52.231.186.18:8123/'
echo 'CREATE TABLE testLF.landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,TIN DateTime,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

#load dataset
echo 'load ------------ 3-12 ------------ dataset in landing table'>> clickhouse_client_landing_final.log 
cat /IndepentProjectData/Data/TableTransac/datatransac_201703_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201704_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201705_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201706_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201707_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201708_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201709_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201710_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201711_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201712_backup.csv | time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.landing FORMAT CSV"

#transfer the landing data to final table
echo 'transfer the landing data 3-12 month to final table'>> clickhouse_client_landing_final.log
time -ao clickhouse_client_landing_final.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testLF   --query="INSERT INTO testLF.final
select ID,
STATIONIDIN,
STATIONIDOUT,
TIN,
DTOUT,
OCTOPUS,
SUBTYPE,
TIME
from testLF.landing"

#truncate or drop-create landing table
echo 'drop-create landing table'>> clickhouse_client_landing_final.log
time -ao clickhouse_client_landing_final.log echo 'drop TABLE testLF.landing '| POST 'http://52.231.186.18:8123/'
time -ao clickhouse_client_landing_final.log echo 'CREATE TABLE testLF.landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,TIN DateTime,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'


echo 'Clickhouse-client test for transaction and kpi STOP--------------------------------------------'>> clickhouse_client_landing_final.log 
date >> clickhouse_client_landing_final.log


