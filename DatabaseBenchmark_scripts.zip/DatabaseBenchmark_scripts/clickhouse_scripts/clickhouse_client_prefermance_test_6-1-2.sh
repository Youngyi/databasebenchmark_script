echo 'test-6.1-6.2-load delete and truncate  ----- start -----'>> load_detele_truncate.log 
date >> load_detele_truncate.log
echo 'create  database test'>> load_detele_truncate.log
echo 'CREATE  DATABASE  IF  NOT  EXISTS  test' | POST 'http://52.231.186.18:8123/'
echo 'create  reference table'>> load_detele_truncate.log
echo 'CREATE TABLE test.STATIONS (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'
echo 'CREATE TABLE test.LINES (LINEID String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'
echo 'CREATE TABLE test.SUBTYPE (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'
#创建 landing Table 和 Final Table 
#KPI 和 transaction 需要 增加一个DTBUSINESS 属性
echo 'create  TRANSAC_landing and TRANSAC'>> load_detele_truncate.log
echo 'CREATE TABLE test.TRANSAC_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE  test.TRANSAC ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTBUSINESS Date,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = MergeTree PARTITION BY DTBUSINESS Order By (DTBUSINESS)'| POST 'http://52.231.186.18:8123/'
echo 'create  KPI_landing and KPI'>> load_detele_truncate.log
echo 'CREATE TABLE test.KPI_landing (STATIONID String, LINEID String, DIRECTION String, DTKPI String, KPI Int64) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE test.KPI (STATIONID String, LINEID String, DIRECTION String, DTKPI Datetime, DTBUSINESS Date, KPI Int64) ENGINE = MergeTree PARTITION BY DTBUSINESS Order By (DTBUSINESS)'| POST 'http://52.231.186.18:8123/'

# 把reference 三个表的数据load进去
#cat /IndepentProjectData/Data/TableReference/postgres_lines/transac_Lines_backup.csv | time -ao -ao /IndepentProjectData/running_log/clickhouse_client_load.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test --query="INSERT INTO test.lines FORMAT CSV"
echo 'load lines data to test database'>> load_detele_truncate.log
cat /IndepentProjectData/Data/TableReference/postgres_lines/transac_Lines_backup.csv |  time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test  --query="INSERT INTO test.LINES FORMAT CSV"
echo 'load stations data to test database'>> load_detele_truncate.log
cat /IndepentProjectData/Data/TableReference/postgres_stations/transac_Stations_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.STATIONS FORMAT CSV"
echo 'load subtype data to test database'>> load_detele_truncate.log
cat /IndepentProjectData/Data/TableReference/postgres_subtype/transac_SubType_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.SUBTYPE FORMAT CSV"
#把KPI_2017，KPI_2018数据load进 KPI_landing
echo 'load kpi data to test database'>> load_detele_truncate.log
cat /IndepentProjectData/Data/TableKpi/postgres_kpi/dataKPI_2017_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.KPI_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableKpi/postgres_kpi/dataKPI_2018_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.KPI_landing FORMAT CSV"
#把KPI_landing 转到 KPI 这个Final表中 在这个过程中，需要把时间进行ETL处理一下
echo 'transfer the KPI_landing data from landing to final table'>> load_detele_truncate.log
time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.KPI
select STATIONID, LINEID, DIRECTION, DTKPI,toDate(substring(toString(DTKPI),1,10)) as DTBUSINESS, KPI from test.KPI_landing"
#把201701数据 load 到 TRANSAC_landing 中
echo 'load --- 1th --- dataset in landing table'>> load_detele_truncate.log
cat /IndepentProjectData/Data/TableTransac/datatransac_201701_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"
#把landing Table 里的数据转到 TRANSAC 这个FinalTable中
echo 'transfer the ----1th-----TRANSAC_landing data TRANSAC table'>> load_detele_truncate.log
time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC
select ID,
STATIONIDIN,
STATIONIDOUT,
DTIN,
toDate(substring(toString(DTIN),1,10)) as DTBUSINESS,
DTOUT,
OCTOPUS,
SUBTYPE,
TIME
from test.TRANSAC_landing"
#对landing Table删除，创建
echo 'drop-create 1 landing table'>> load_detele_truncate.log
time -ao load_detele_truncate.log echo 'drop TABLE test.TRANSAC_landing '| POST 'http://52.231.186.18:8123/'
time -ao load_detele_truncate.log echo 'CREATE TABLE test.TRANSAC_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

#load dataset
echo 'load ------------ 2th ------------ dataset in landing table'>> clickhouse_client_landing_final.log 
cat /IndepentProjectData/Data/TableTransac/datatransac_201702_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"

echo 'transfer the ---2th--- TRANSAC_landing data TRANSAC table'>> load_detele_truncate.log
time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC
select ID,
STATIONIDIN,
STATIONIDOUT,
DTIN,
toDate(substring(toString(DTIN),1,10)) as DTBUSINESS,
DTOUT,
OCTOPUS,
SUBTYPE,
TIME
from test.TRANSAC_landing"

echo 'drop-create ---2th--- landing table'>> load_detele_truncate.log
time -ao load_detele_truncate.log echo 'drop TABLE test.TRANSAC_landing '| POST 'http://52.231.186.18:8123/'
time -ao load_detele_truncate.log echo 'CREATE TABLE test.TRANSAC_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'


echo 'load transac all ---3-12th--- month data to test database'>> load_detele_truncate.log
cat /IndepentProjectData/Data/TableTransac/datatransac_201703_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201704_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201705_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201706_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201707_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201708_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201709_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201710_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201711_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"
cat /IndepentProjectData/Data/TableTransac/datatransac_201712_backup.csv | time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC_landing FORMAT CSV"

echo 'transfer the ---3-12th--- TRANSAC_landing data TRANSAC table'>> load_detele_truncate.log
time -ao load_detele_truncate.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test   --query="INSERT INTO test.TRANSAC
select ID,
STATIONIDIN,
STATIONIDOUT,
DTIN,
toDate(substring(toString(DTIN),1,10)) as DTBUSINESS,
DTOUT,
OCTOPUS,
SUBTYPE,
TIME
from test.TRANSAC_landing"
echo 'drop-create ---3-12th--- landing table'>> load_detele_truncate.log
time -ao load_detele_truncate.log echo 'drop TABLE test.TRANSAC_landing '| POST 'http://52.231.186.18:8123/'
time -ao load_detele_truncate.log echo 'CREATE TABLE test.TRANSAC_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'





date >>load_detele_truncate.log
echo 'test-6.1-6.2-load delete and truncate  ----- stop -----'>> load_detele_truncate.log


