# connect with server:
##clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database test
echo 'Test all queries in testsql database, fist step-load data and etl -----start'>> etl_2018.log 
date >> etl_2018.log

echo 'CREATE  DATABASE  IF  NOT  EXISTS  testsql' | POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE testsql.KPI (STATIONID String, LINEID String, DIRECTION String, DTKPI DateTime, KPI Int64) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE testsql.TRANSAC ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE testsql.STATIONS (STATIONID String, STATIONDESC String, MAINLINEID String) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE testsql.LINES (LINEID String, LINEDESC String, LINECOLOR String) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE testsql.SUBTYPE (SUBTYPEID String, SUBTYPEDESC String) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'


#substring(TIN,1,4) || '-' || substring(TIN,5,2) || '-' || substring(TIN,7,2)
#create table landing and final in testsqlLF
echo 'CREATE TABLE testsql.transac_2018_landing ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN String,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'
#增加一个DTBUSINESS 属性
echo 'CREATE TABLE  testsql.transac_2018_final ( ID Int32, STATIONIDIN String, STATIONIDOUT String,DTIN DateTime,DTBUSINESS Date,DTOUT DateTime,OCTOPUS String,SUBTYPE String,TIME Int64 ) ENGINE = MergeTree PARTITION BY DTBUSINESS Order By (DTBUSINESS)'| POST 'http://52.231.186.18:8123/'

echo 'CREATE TABLE testsql.kpi_2018_landing(STATIONID String, LINEID String, DIRECTION String, DTKPI String, KPI Int64) ENGINE = TinyLog'| POST 'http://52.231.186.18:8123/'
#增加一个DTBUSINESS 属性
echo 'CREATE TABLE testsql.kpi_2018_final (STATIONID String, LINEID String, DIRECTION String, DTKPI Datetime, DTBUSINESS Date, KPI Int64) ENGINE = MergeTree PARTITION BY DTBUSINESS Order By (DTBUSINESS)'| POST 'http://52.231.186.18:8123/'

#load dataset 
echo 'load transac 2018 dataset in landing table'>> etl_2018.log 
cat /IndepentProjectData/Data/TableTransac/datatransac_201801_backup.csv | time -ao etl_2018.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testsql   --query="INSERT INTO testsql.transac_2018_landing FORMAT CSV"

echo 'load lines dataset in landing table'>> etl_2018.log 
cat /IndepentProjectData/Data/TableReference/postgres_lines/transac_Lines_backup.csv | time -ao etl_2018.log  clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testsql  --query="INSERT INTO testsql.LINES FORMAT CSV"
echo 'load stations dataset in landing table'>> etl_2018.log 
cat /IndepentProjectData/Data/TableReference/postgres_stations/transac_Stations_backup.csv | time -ao etl_2018.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testsql   --query="INSERT INTO testsql.STATIONS FORMAT CSV"
echo 'load subtype dataset in landing table'>> etl_2018.log 
cat /IndepentProjectData/Data/TableReference/postgres_subtype/transac_SubType_backup.csv | time -ao etl_2018.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testsql   --query="INSERT INTO testsql.SUBTYPE FORMAT CSV"

echo 'load kpi 2018 dataset in landing table'>> etl_2018.log 
cat /IndepentProjectData/Data/TableKpi/postgres_kpi/dataKPI_2018_backup.csv | time -ao etl_2018.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testsql   --query="INSERT INTO testsql.kpi_2018_landing FORMAT CSV"

#transfer the landing data to final table
echo 'transfer the transac_2018 data from landing to final table'>> etl_2018.log
time -ao etl_2018.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testsql   --query="INSERT INTO testsql.transac_2018_final
select ID,
STATIONIDIN,
STATIONIDOUT,
DTIN,
toDate(substring(toString(DTIN),1,10)) as DTBUSINESS,
DTOUT,
OCTOPUS,
SUBTYPE,
TIME
from testsql.transac_2018_landing"

echo 'transfer the kpi_2018 data from landing to final table'>> etl_2018.log
time -ao etl_2018.log clickhouse-client --host 52.231.186.18 --port 9000 --user admin --password admin01 --database testsql   --query="INSERT INTO testsql.kpi_2018_final
select STATIONID, LINEID, DIRECTION, DTKPI,toDate(substring(toString(DTKPI),1,10)) as DTBUSINESS, KPI from testsql.kpi_2018_landing"
echo 'Test all queries in testsql database, fist step-load data and etl -----stop'>> etl_2018.log 


