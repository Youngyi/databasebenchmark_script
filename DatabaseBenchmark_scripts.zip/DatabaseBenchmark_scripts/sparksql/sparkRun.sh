#cd /Users/myy/Desktop/5003
cd /usr/local/
./bin/pyspark --packages graphframes:graphframes:0.5.0-spark2.1-s_2.11
